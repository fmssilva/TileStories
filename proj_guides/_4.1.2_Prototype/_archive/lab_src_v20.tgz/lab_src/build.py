"""Builds the World Editor Lab: joins the parts listed in PARTS, inlines every @@NAME@@ from media/NAME.txt.
usage: python3 build.py <out.html>"""
import os, re, sys
here = os.path.dirname(os.path.abspath(__file__))
parts = [p for p in open(os.path.join(here, "PARTS")).read().split("\n") if p]
html = "".join(open(os.path.join(here, p)).read() for p in parts)
html = html[:-1]  # each part ends with a newline; the original file did not
def media(m):
    f = os.path.join(here, "media", m.group(1) + ".txt")
    if not os.path.exists(f): sys.exit(f"missing media: {m.group(1)}")
    return open(f).read()
html = re.sub(r"@@([A-Z0-9_]+)@@", media, html)
open(sys.argv[1], "w").write(html)
print("built", sys.argv[1], len(html), "bytes")
