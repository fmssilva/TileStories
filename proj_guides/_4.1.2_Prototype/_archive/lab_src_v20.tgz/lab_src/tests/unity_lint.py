"""Unity feasibility lint for the Lab CSS (mk_review/unity_feasibility.md §5).
Checks the kids_*.css files strictly; with --all also reports ds.css / tap.css (informative).
Forbidden: backdrop-filter, filter: drop-shadow/brightness/saturate, mask(-image), mix-blend-mode, clip-path, perspective,
preserve-3d, rotateX/rotateY, cubic-bezier(), background-clip:text, outline(-offset), conic-gradient,
box-shadow with a blur (unless the rule is tagged /* unity: sprite */), @keyframes (unless tagged /* tween: */),
gradients (unless tagged /* unity: ramp */ or /* unity: sprite */)."""
import re, sys, glob, os
HERE = os.path.dirname(os.path.abspath(__file__))
RULES = [(r"backdrop-filter", "backdrop-filter (camera glass only)"), (r"filter\s*:\s*[^;}]*(drop-shadow|brightness|saturate)", "filter drop-shadow/brightness/saturate"),
    (r"(?<![-\w])mask(-image)?\s*:", "mask"), (r"-webkit-mask", "mask"), (r"mix-blend-mode", "mix-blend-mode"), (r"clip-path", "clip-path"),
    (r"perspective\s*[:(]", "perspective"), (r"preserve-3d", "preserve-3d"), (r"rotate[XY]\(", "3D rotate"), (r"cubic-bezier\(", "cubic-bezier (use named easing)"),
    (r"background-clip\s*:\s*text", "background-clip:text"), (r"border-image-outset", "border-image-outset (Unity: a sibling image, negative margins)"),
    (r"(?<![-\w])transform\s*:\s*translate", "transform: translate (use the translate property)"), (r":\s*inherit\b", "inherit"), (r"\bcqw\b", "cqw"), (r"dashed", "dashed border (Unity: a slot sprite)"), (r"(?<![-\w])outline(-offset)?\s*:", "outline"), (r"conic-gradient", "conic-gradient")]
def rules(css):
    for m in re.finditer(r"([^{}]+)\{([^{}]*)\}", re.sub(r"@media[^{]*\{", "", css)): yield m.group(1).strip(), m.group(2), m.group(0)
def lint(path):
    css = open(path).read(); out = []
    for m in re.finditer(r":has\(", css): out.append((":has()", css[max(0, m.start() - 60):m.start()].split("}")[-1].strip()[-60:]))
    for sel, body, full in rules(css):
        tagged = lambda t: t in full
        for rx, name in RULES:
            b2 = re.sub(r"--k-back\s*:\s*cubic-bezier\([^)]*\)", "", body) if "unity: ease-out-back" in full else body   # the one whitelisted easing token
            if re.search(rx, b2): out.append((name, sel[-90:]))
        for sh in re.findall(r"box-shadow\s*:\s*([^;}]*)", body):
            for part in re.split(r",(?![^(]*\))", sh):
                nums = re.findall(r"(-?[\d.]+)(px|pt|em)?|calc\([^)]*\)", part)
                lens = [t for t in re.findall(r"calc\([^()]*(?:\([^()]*\)[^()]*)*\)|-?[\d.]+px|\b0\b", part)]
                if part.strip() in ("none", "none!important") or "inset" in part: continue
                if len(lens) >= 3 and lens[2] not in ("0", "0px") and not tagged("unity: sprite"): out.append(("soft box-shadow untagged", sel[-90:]))
        if re.search(r"(linear|radial)-gradient", body) and not (tagged("unity: ramp") or tagged("unity: sprite")): out.append(("gradient untagged", sel[-90:]))
    for m in re.finditer(r"@keyframes\s+([\w-]+)", css):
        if "tween:" not in css[max(0, m.start() - 200):m.start() + 400]: out.append(("@keyframes untagged", m.group(1)))
    return out
if __name__ == "__main__":
    files = sorted(glob.glob(os.path.join(HERE, "..", "css", "kids_*.css")))
    bad = 0
    for f in files:
        r = lint(f); bad += len(r)
        for name, sel in r: print(f"{os.path.basename(f)}: {name} :: {sel}")
    print(f"unity lint: {len(files)} kids files, {bad} problems")
    if "--all" in sys.argv:
        for f in ["ds.css", "tap.css"]:
            r = lint(os.path.join(HERE, "..", "css", f)); print(f"(info) {f}: {len(r)} items to map before Unity")
    sys.exit(1 if bad else 0)
