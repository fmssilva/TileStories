# World Editor Lab -- source

## Working rules (same as the main project)
One Lab, one artifact: every version is published over the same artifact (same link), never a copy. The source of truth
is this folder; `World_Editor_Lab.html` is built from it.

For every feature, in this order:
1. **Implement** in the parts (`js/`, `css/`), keeping the code organised: one concern per file, no dead code, names that
   say what they are. A feature the Unity guides will need gets a comment that names its Unity counterpart.
2. **Build and check it runs:** `python3 build.py <out.html>`, then the page loads with no console error.
3. **Check it visually** (screenshots, opened and looked at): modern, premium, minimalist, immersive, 3D. On a phone and a
   tablet, portrait and landscape, Dark and Light. Nothing overlaps, nothing covers the POI, text is readable. For a new
   screen or a design round, two independent critic agents review the screenshots (premium AR design; UX and
   accessibility), then re-check after the fixes.
4. **Add tests** for the base case and the edge cases (`tests/regress.py` feature checks, `tests/sweep.py` placement
   over many camera poses and devices), run both, compare with `tests/report_baseline.json`, then re-baseline.
5. **Publish** the new version over the same artifact; record it in `SESSION_LOG_4.1.md` and the guides (version 0).

Editor rules: Unity conventions (foldouts, ReorderableList for named lists, Prefab-style overrides: bold + blue bar + ↺);
every section starts collapsed and section titles stick to the top; clicking a config opens the screen that shows it;
the view is full height with only the screen tabs, device buttons, ▶ / ↻, Undo / Redo and ⌨ above it.

The Lab is one self-contained HTML page (`../World_Editor_Lab.html`), built from these parts. Edit the parts, never the
built page.

- `PARTS` -- the order the parts are joined in. Order matters: it is one script, run top to bottom.
- `shell_head.html`, `css/lab.css`, `shell_body.html`, `js/*.js`, `shell_end.html` -- the page.
- `media/*.txt` -- the panorama and the sample photos (data URIs), inlined at `@@NAME@@`.
- `build.py` -- `python3 build.py ../World_Editor_Lab.html`

js/, in load order:

| File | What |
|---|---|
| 00_core | constants and small helpers |
| 01_data, 02_media | the sample config (styles, levels, POIs, Wall Life, app, experiences); media sources |
| media/*.txt | the panorama and the sample photos as data URIs, inlined by build.py at `@@NAME@@` |
| 03_state, 04_geometry | UI state, undo, selectors; splines → points, offsets, precision |
| 05_render_regions, 06_render_wall | drawing a region / point / label; the canvas, spotlight, the wall as seen |
| 07_screens, 08_wall_life | the Style and Precision screens; Wall Life (K1-K6) state and drawing |
| 09_handles_loop, 10_input, 11_play_hud | Scene handles and the frame loop; mouse and keys; Play, screens, HUD |
| 20_editor_kit | the Unity-like rows, fields, foldouts, help texts |
| 21-27 | the editor tabs: Global Scene, Wall Life rows, Specific Marker, App (+ the phone), cards, Experiences, Decisions |
| 28_editor_shell, 29_json | render the editor, tab buttons; the config.json preview |
| 12_device | the device frame (phone / tablet, portrait / landscape, buttons in the top bar) and the 3D camera |
| 32_design (+ css/ds.css, css/fonts.css) | App › 1 Design system, the app's UI kit: foundations (look and mode, colour, type, spacing and shape, depth and motion), components (buttons, panels, controls, lists and messages), patterns (navigation, sheets and dialogs); one phone page per subsection; the component builders (dsBtn, dsRow, dsList, dsNavBar…) used by Start, Onboarding and Explore |
| 31_main | App › 4 Main AR screen: search (+ Settings gear), category filter, Near, mini-map, the action bar (BAR catalogue, 2–5 buttons), coach mark, out-of-view hint; Pointing inside |
| 33_markers | point (marker) styles and their drawing; the Playful "Tile disc" |
| 34_profiles | visitor profiles (look, mode, audience, time, text, interests, prefs); the look views (D.ds / D.themes are Proxies of the live look); the profile bar; onboarding, Settings, You; Coming soon copy |
| 35_kids_kit, 36_kids_flows | the Playful kit (Azu sprites, 9-slice frames, doodles) and its flows (Azu greeting, sticker, tile album) |
| 30_tap (+ css/tap.css) | On tap: base elements (buttons), tag and action components, the styles and their resolver (default › level › POI + field overrides), the renderer shared by the phone and the Wall screen, the action views (card, 360, then & now, 3D preview) |
| 12_device | the device frame (phone/tablet, portrait/landscape) and the 3D camera: project, unproject, navigation |
| 99_boot | start-up |

CSS: `css/ds.css` (the app UI kit, both looks, base) → `css/kids_00…50_*.css` (Playful, scoped `.tapc.look-playful`) and
`css/prem_{foundations,surfaces,main,tap,flows}.css` (Premium, scoped `.tapc:not(.look-playful)`), one file per group.
Unity feasibility is enforced by `tests/unity_lint.py`.

## Review tools (`tools/review/`)
- `section_shots.py`: one contact sheet per editor fold (6 profile rows × devices) from `inventory.json` (`inventory.py` regenerates it).
- `state_shots.py`: contact sheets of named app states (onb, settings, you, main, imm, pan, soon…).
- `fitcheck.py`, `probe.py`: measure clipping / overflow / 48 pt targets.
- `AGENT_PROMPT.md`, `BRIEF_v20_example.md`: how review + fix agents were briefed.

## Safety net (run after every change)

```
python3 build.py /tmp/lab.html
python3 tests/regress.py /tmp/lab.html /tmp/report.json        # 153 feature checks + every editor header + screens
python3 tests/sweep.py /tmp/lab.html --verbose                 # 4 devices × 6 styles × 80 poses + side views + big markers: rules R1-R6
SWEEP_INIT="setProfile('visitors','children')" python3 tests/sweep.py /tmp/lab.html   # the same under Playful
python3 tests/unity_lint.py                                    # 0 problems: only Unity-feasible CSS
python3 tests/compare.py tests/report_baseline.json /tmp/report.json   # what changed against the baseline
```
Needs Python Playwright with Chrome. A difference must be one you meant; when it is, save the new report as the baseline.

### Every editor section has a demo
A section (fold) opens the screen that shows it: `screen` / `step` for a screen, `demo: { step, preview, poi, view }` for a
specific demo (a UI kit page, a component, a POI's tap, an action view). Opening the section, or a click inside it, puts the
phone on that demo (`runDemo`, only when it is not already there). The only sections without one are plans with nothing
built yet (Geo-reference, Ambient sound, Capture & share), the locked Unity sections and the config.json preview; a test
(`every editor section has a demo…`) keeps it so.

### Design tokens
The tokens follow the Unity theme (`Theme.default.uss`); the final list is `proj_guides/_4.1.7_App_Design_System.md`.
- Fonts: `css/fonts.css` embeds the project's own Fraunces SemiBold and Atkinson Hyperlegible Next (media/FONT_*.txt, base64).
- Sizes are written in pt: `--P` = 1 pt (`--u` / 3.9). Type: 28 / 24 / 20 / 16 / 15 / 14 / 13; controls 48, chips 32.
- `dsT()` = the base tokens with the audience's changes (Explorer / Family / Expert); `applyDS()` writes them as CSS variables.
- Colour: `D.themes` (light, dark) hold the roles; the accent comes from `ACCENTS` (closed list, `setAccent`).
- Glass: `D.ds.glass` = blur (a camera-blur shader in Unity) or solid (no blur, dense tint: the Unity 6.3 look).
