/* ---------- On tap: named layouts (focus · tag · actions · screen card · ask), the renderer shared by the phone and the Wall screen, and the action views ---------- */
const TAP_OPTS = {
  focus:   [["ring", "Ring"], ["pulse", "Pulse"], ["spotlight", "Spotlight (dim the rest)"], ["none", "None"]],
  tag_kind: [["label", "Label (name only)"], ["chip", "Chip (name + line)"], ["card", "Compact card"], ["immersive", "Immersive card (image is the card)"], ["panel", "Floating panel (leader line)"]],
  place:   [["auto", "Auto"], ["above", "Above the POI"], ["below", "Below the POI"]],
  act_kind: [["radial", "Radial around the POI"], ["capsule", "Floating capsule"], ["in_tag", "Inside the tag"], ["dock", "Dock row at the bottom"], ["tiles", "Tiles in the screen card"]],
  sheet:   [["none", "None"], ["peek", "Peek"], ["half", "Half, with image"]],
  ask:     [["off", "Off"], ["capsule", "In the capsule"], ["sheet", "In the screen card"]],
};
/* the On-tap system, in three layers (App › On tap):
   1. base elements: the action buttons (one per action type, in priority order) and how a button looks;
   2. components: finished tag components (label, chip, card, immersive, panel) and action components (radial, capsule…);
   3. on-tap styles: which components a tap shows and how they are arranged.
   The app has a default style; a level may pick another; a POI may pick another and override single fields. */
D.tap_actions = [
  { key: "card", label: "Card", show: "always" },
  { key: "model_wall", label: "3D", show: "auto" },
  { key: "model_screen", label: "3D view", show: "auto" },
  { key: "pano", label: "360°", show: "auto" },
  { key: "then_now", label: "Then & now", show: "auto" },
  { key: "play", label: "Play", show: "auto" },
  { key: "map", label: "Map", show: "always" },
  { key: "favourite", label: "Save", show: "always" },
  { key: "ask", label: "Ask", show: "always" },
  { key: "navigate", label: "Go", show: "off" },
  { key: "share", label: "Share", show: "off" },
  { key: "tour", label: "Tour", show: "off" },
  { key: "quiz", label: "Quiz", show: "auto" },
];
/* "auto": the button shows only when the POI has the content for it (framework code, one rule per action type) */
const NEEDS = {
  model_wall: [p => !!p.actions?.model?.file, "a 3D model"], model_screen: [p => !!p.actions?.model?.file, "a 3D model"],
  pano: [p => !!p.media?.pano, "a 360 photo"], then_now: [p => !!p.media?.today, "a today photo"], play: [p => !!p.media?.video, "a video or audio"],
  quiz: [p => !!p.quiz, "a quiz"],
};
D.tap_button = { size: 1, shape: "circle", surface: "glass" };
D.tap_tags = [
  { key: "tag_comp_1", name: "Label", kind: "label" },
  { key: "tag_comp_2", name: "Chip", kind: "chip", show_cat: true, show_summary: true },
  { key: "tag_comp_3", name: "Compact card", kind: "card", media: "image", show_cat: true, show_summary: true },
  { key: "tag_comp_4", name: "Immersive card", kind: "immersive", size: "M", media: "image", show_cat: true, show_summary: true },
  { key: "tag_comp_5", name: "Floating panel", kind: "panel", media: "image", show_cat: false, show_summary: true },
];
D.tap_action_comps = [
  { key: "act_comp_1", name: "Radial ring", kind: "radial", max: 5, labels: true },
  { key: "act_comp_2", name: "Capsule", kind: "capsule", max: 4, labels: true },
  { key: "act_comp_3", name: "Links in the tag", kind: "in_tag", max: 4, labels: false },
  { key: "act_comp_4", name: "Dock", kind: "dock", max: 5, labels: true },
  { key: "act_comp_5", name: "Tiles", kind: "tiles", max: 6, labels: true },
];
const SCREEN = { focus: false, tag: false, actions: false };
D.tap_layouts = [
  { key: "tap_layout_1", name: "Minimal", focus: "ring", tag: "tag_comp_2", place: "auto", actions: "act_comp_2", sheet: "none", ask: "capsule", on_wall: { ...SCREEN }, depth_cm: 8, gap: 0 },
  { key: "tap_layout_2", name: "Radial", focus: "ring", tag: "tag_comp_2", place: "auto", actions: "act_comp_1", sheet: "peek", ask: "off", on_wall: { ...SCREEN }, depth_cm: 8, gap: 0 },
  { key: "tap_layout_3", name: "Immersive card", focus: "spotlight", tag: "tag_comp_4", place: "auto", actions: "act_comp_3", sheet: "none", ask: "off", on_wall: { ...SCREEN }, depth_cm: 8, gap: 0 },
  { key: "tap_layout_4", name: "Floating panels", focus: "pulse", tag: "tag_comp_5", place: "below", actions: "act_comp_3", sheet: "none", ask: "off", on_wall: { focus: true, tag: true, actions: true }, depth_cm: 10, gap: 0 },
  { key: "tap_layout_5", name: "Sheet with tiles", focus: "ring", tag: "tag_comp_1", place: "auto", actions: "act_comp_5", sheet: "peek", ask: "sheet", on_wall: { ...SCREEN }, depth_cm: 8, gap: 0 },
  { key: "tap_layout_6", name: "Card only", focus: "ring", tag: "none", place: "auto", actions: "none", sheet: "half", ask: "off", on_wall: { ...SCREEN }, depth_cm: 8, gap: 0 },
  { key: "tap_layout_7", name: "Focus only", focus: "ring", tag: "none", place: "auto", actions: "none", sheet: "none", ask: "off", on_wall: { ...SCREEN }, depth_cm: 8, gap: 0 },
];
/* the style a POI uses (preview › POI › level › app default) and the flat layout the renderer reads (components and POI overrides resolved) */
const tapStyleByKey = k => D.tap_layouts.find(t => t.key === k);
const tagComp = k => D.tap_tags.find(t => t.key === k), actComp = k => D.tap_action_comps.find(t => t.key === k);
/* a component preview (App › On tap): the phone shows one tag or one action component on the POI, alone */
function compPreviewStyle() {
  const C = ui.compPreview; if (!C || C.type === "buttons") return null;
  if (C.type === "tag") return { key: "_comp", name: "Tag · " + (tagComp(C.key)?.name || ""), focus: "ring", tag: C.key, place: "auto", actions: "none", sheet: "none", ask: "off", on_wall: { ...SCREEN }, depth_cm: 0, gap: 0 };
  const A = actComp(C.key), tagFor = A?.kind === "in_tag" ? "tag_comp_3" : A?.kind === "radial" ? "none" : "tag_comp_1";
  return { key: "_comp", name: "Buttons · " + (A?.name || ""), focus: "ring", tag: D.tap_tags.some(t => t.key === tagFor) ? tagFor : "none", place: "auto", actions: C.key, sheet: A?.kind === "tiles" ? "peek" : "none", ask: "off", on_wall: { ...SCREEN }, depth_cm: 0, gap: 0 };
}
function tapStyleOf(p) {
  const cp = compPreviewStyle(); if (cp) return cp; return tapStyleByKey(ui.previewLayout) || tapStyleByKey(p?.on_tap?.tap_layout) || tapStyleByKey(levelOf(p)?.tap_layout) || tapStyleByKey(D.app.tap.default_layout) || D.tap_layouts[0]; }
const OVERRIDABLE = ["tag", "actions", "focus", "gap", "depth_cm"];
function tapLayoutOf(p) {
  const S = tapStyleOf(p), o = (!ui.previewLayout && !ui.compPreview) ? p?.on_tap?.over || {} : {};
  const M = { ...S }; OVERRIDABLE.forEach(k => { if (o[k] !== undefined) M[k] = o[k]; });
  const T = tagComp(M.tag), A = actComp(M.actions);
  return { ...M, style: S, tagComp: T, actComp: A, tag: T ? T.kind : "none", actions: A ? A.kind : "none", max: A?.max ?? 4, labels: A?.labels ?? false, gap: +M.gap || 0 };
}
/* the buttons a POI offers: the catalogue order; "auto" ones only when the POI has the content; the POI may hide or force one */
function poiActions(p) {
  const o = p?.on_tap?.over?.buttons || {};
  return D.tap_actions.filter(a => o[a.key] === "hide" ? false : o[a.key] === "show" ? true : a.show === "always" || (a.show === "auto" && (NEEDS[a.key]?.[0](p) ?? true))).map(a => a.key);
}
const actionLabel = k => D.tap_actions.find(a => a.key === k)?.label || ACTIONS[k]?.label || k;
const tapSummary = S => [S.focus === "none" ? "—" : S.focus, tagComp(S.tag)?.name || "—", actComp(S.actions)?.name || "—", S.sheet === "none" ? "—" : S.sheet + " card", S.ask === "off" ? "—" : "ask"].join(" · ");
const SHORT = { card: "Card", model_wall: "3D", model_screen: "3D view", pano: "360°", map: "Map", then_now: "Then & now", play: "Play", ask: "Ask", navigate: "Go", favourite: "Save", share: "Share", tour: "Tour", quiz: "Quiz" };
const ICONS = {
  card: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  model_wall: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>',
  model_screen: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M12 7.5l3 1.7v3.6l-3 1.7-3-1.7V9.2z"/><path d="M8 21h8"/>',
  pano: '<path d="M3 12c0-2.5 4-4.5 9-4.5s9 2 9 4.5-4 4.5-9 4.5"/><path d="M8 14.5L5.5 17 8 19.5"/>',
  map: '<path d="M12 21s-6-5.5-6-10a6 6 0 0112 0c0 4.5-6 10-6 10z"/><circle cx="12" cy="11" r="2.2"/>',
  then_now: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M12 3v18"/>',
  play: '<circle cx="12" cy="12" r="9"/><path d="M10 8.5l5 3.5-5 3.5z"/>',
  ask: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',
  navigate: '<path d="M4 11l16-7-7 16-2-7z"/>',
  favourite: '<path d="M12 20s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.6-7 10-7 10z"/>',
  share: '<path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 13v6h14v-6"/>',
  tour: '<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h6a3 3 0 000-6h-4a3 3 0 010-6h6"/>',
  quiz: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 114 2c-1 .7-1.5 1.2-1.5 2.5M12 17h.01"/>',
  more: '<circle cx="6" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="18" cy="12" r="1.3"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>', mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/>',
  send: '<path d="M4 12l16-8-6 16-2-6z"/>', chev: '<path d="M9 6l6 6-6 6"/>', up: '<path d="M6 15l6-6 6 6"/>',
};
const svg = k => { const t = document.createElement("template"); t.innerHTML = `<svg viewBox="0 0 24 24">${ICONS[k] || ICONS.more}</svg>`; return t.content.firstChild; };
/* the POI's own picture: the wall photo framed on its shapes (stands in for the card's hero image) */
function poiImage(p, pad = 0.18) {
  const b = bboxOf(p); let bw = b.x1 - b.x0, bh = b.y1 - b.y0;
  if (bw < 30) { b.x0 = p.pos.x - 40; bw = 80; } if (bh < 30) { b.y0 = p.pos.y - 40; bh = 80; }
  const x0 = Math.max(0, b.x0 - bw * pad), y0 = Math.max(0, b.y0 - bh * pad), w = Math.min(IW - x0, bw * (1 + 2 * pad)), hh = Math.min(IH - y0, bh * (1 + 2 * pad));
  return `background-image:url(${SRC});background-size:${IW / w * 100}% ${IH / hh * 100}%;background-position:${x0 / Math.max(1, IW - w) * 100}% ${y0 / Math.max(1, IH - hh) * 100}%`;
}
/* the POI's hero image: its photo when it has one, else the tiles framed on its shapes */
const heroStyle = (p, pad) => p.media?.hero ? `background-image:url(${PHOTOS[p.media.hero]});background-size:cover;background-position:center` : poiImage(p, pad);
const tapState = { view: null, toast: "", favs: {}, toastT: 0 };
function tapButtons(p, L) {
  const acts = poiActions(p).filter(a => a !== "ask" || L.ask === "off");
  const shown = acts.slice(0, L.max), more = acts.length - shown.length;
  const out = shown.map(a => ({ a, icon: a, label: actionLabel(a) }));
  if (more > 0) out.push({ a: "more", icon: "more", label: "+" + more, more: true });
  return out;
}
/* draws the tap UI for POI p at (x %, y %) of root into root (a .tapc layer). opts: { interactive, rerender } */
function tapUI(root, p, x, y, L, opts = {}) {
  const act = opts.interactive ? a => e => { e.stopPropagation(); tapAction(p, a, opts.rerender); } : () => null;
  const add = el => { root.append(el); return el; };
  const btns = tapButtons(p, L), ar = root.dataset.ar ? +root.dataset.ar : PHR;
  const toC = Math.hypot(50 - x, (50 - y) / ar) < 12 ? -Math.PI / 2 : Math.atan2((50 - y) / ar, 50 - x);   // from the POI towards the screen centre
  const above = L.place === "above" || (L.place === "auto" && (L.actions === "radial" ? Math.sin(toC) > 0.2 || (Math.sin(toC) > -0.2 && y > 50) : y > 46));
  const col = catColor(p), T = L.tagComp || {}, cat = T.show_cat === false ? "" : CATS[p.category]?.label || "", sum = T.show_summary === false ? "" : p.summary || "", G = L.gap || 0;
  const media = (pad) => T.media === "none" ? "background:linear-gradient(160deg,#2A3550,#121826)" : heroStyle(p, pad);
  const vid = () => T.media === "video" ? h("span", { class: "vidb" }, svg("play")) : null;
  root.style.setProperty("--g", G); root.style.setProperty("--bk", D.tap_button.size);
  root.classList.toggle("b-round", D.tap_button.shape === "rounded"); root.classList.toggle("b-solid", D.tap_button.surface === "solid");
  // focus
  if (L.focus === "spotlight") add(h("div", { class: "f-spot fade", style: `background:radial-gradient(circle at ${x}% ${y}%, rgba(0,0,0,0) calc(9 * var(--u)), rgba(5,7,12,.62) calc(30 * var(--u)))` }));
  if (L.focus === "ring") add(h("div", { class: "f-ring pop", style: `left:${x}%;top:${y}%` }));
  if (L.focus === "pulse") { add(h("div", { class: "f-pulse", style: `left:${x}%;top:${y}%` })); add(h("div", { class: "f-pulse", style: `left:${x}%;top:${y}%;animation-delay:.9s` })); }
  add(h("div", { class: "f-dot pop", style: `left:${x}%;top:${y}%` }));
  const uw = +root.dataset.uw || 1, cx = Math.min(100 - 36 * uw, Math.max(36 * uw, x)), off = above ? `bottom:calc(${100 - y}% + ${13 + G} * var(--u))` : `top:calc(${y}% + ${13 + G} * var(--u))`;
  const iconRow = cls => h("div", { class: cls }, ...btns.map((b, k) => h("span", { class: "i hit pop", title: b.label, style: `animation-delay:${.15 + k * .05}s`, onclick: act(b.a) }, svg(b.icon))));
  const open = opts.interactive ? e => { e.stopPropagation(); tapAction(p, "card", opts.rerender); } : null;
  // tag
  if (L.tag === "label") add(h("div", { class: "t-label g rise hit", style: `left:${cx}%;${off};transform:translateX(-50%)`, onclick: open }, p.name));
  if (L.tag === "chip") add(h("div", { class: "t-chip g rise hit", style: `left:${cx}%;${off};transform:translateX(-50%)`, onclick: open },
    h("span", { class: "cd", style: `background:${col}` }), h("div", {}, h("b", {}, p.name), (cat || sum) ? h("small", {}, [cat, sum.split(",")[0].slice(0, 26)].filter(Boolean).join(" · ")) : null), h("span", { class: "chev" }, svg("chev"))));
  if (L.tag === "card") add(h("div", { class: "t-card g rise hit", style: `left:${cx}%;${off};transform:translateX(-50%)`, onclick: open },
    T.media === "none" ? null : h("div", { class: "th", style: media() }, vid()), h("div", { style: "flex:1;min-width:0" }, cat ? h("small", { class: "cat2" }, cat) : null, h("b", {}, p.name), sum ? h("span", {}, sum) : null,
      L.actions === "in_tag" ? h("div", { class: "irow", style: "margin-top:calc(2 * var(--u))" }, ...btns.map(b => h("span", { class: "i hit", title: b.label, style: "background:rgba(255,255,255,.14);border:0;color:#fff", onclick: act(b.a) }, svg(b.icon)))) : null),
    h("span", { class: "chev" }, svg("chev"))));
  if (L.tag === "immersive") {
    const fav = tapState.favs[p.id];
    const W = { S: 54, M: 66, L: 78 }[T.size || "M"];
    add(h("div", { class: "t-imm rise hit", style: `width:calc(${W} * var(--u));left:${Math.min(100 - (W / 2 + 5) * uw, Math.max((W / 2 + 5) * uw, x))}%;${above ? `bottom:calc(${100 - y}% + ${10.8 + G} * var(--u))` : `top:calc(${y}% + ${10.8 + G} * var(--u))`};transform:translateX(-50%);${media(0.08)}`, onclick: open },
      h("div", { class: "sh" }), vid(), h("span", { class: "heart hit" + (fav ? " on" : ""), onclick: act("favourite") }, svg("favourite")),
      h("div", { class: "bd" }, cat ? h("span", { class: "cat" }, cat) : null, h("b", {}, p.name), sum ? h("span", {}, sum) : null, L.actions === "in_tag" ? iconRow("irow") : null)));
  }
  if (L.tag === "panel") {
    const roomForImage = T.media !== "none" && (x > 50 ? 100 - x : x) / uw >= 40, inImage = T.media !== "none" && !roomForImage;   // no room beside the line: the picture goes on top of the text
    const lh = 14 + G, up = y > 60, ty = up ? y - 2 : y + 2, left = x > 50, at = up ? `top:calc(-${lh + 2} * var(--u));transform:translateY(-100%)` : `top:calc(${lh + 2} * var(--u))`;
    add(h("div", { class: "t-pan", style: `left:${x}%;top:${ty}%;height:0` },
      h("div", { class: "ln", style: `left:0;top:${up ? `calc(-${lh} * var(--u))` : "0"};height:calc(${lh} * var(--u))` }),
      h("div", { class: "tx rise", style: `${at};${left ? "right:calc(2 * var(--u));text-align:right" : "left:calc(2 * var(--u))"};animation-delay:.3s;width:calc(50 * var(--u))` }, inImage ? h("div", { class: "im in hit", style: media(), onclick: open }, vid()) : null, cat ? h("small", { class: "cat2" }, cat) : null, h("b", {}, p.name), h("span", { style: left ? "margin-left:auto" : "" }, p.summary || ""),
        L.actions === "in_tag" ? h("div", { class: "lk", style: left ? "justify-content:flex-end" : "" }, ...btns.map(b => h("span", { class: "hit", onclick: act(b.a) }, b.label))) : null),
      !roomForImage ? null : h("div", { class: "im rise hit", style: `${left ? "left:calc(4 * var(--u))" : "right:calc(4 * var(--u))"};${up || y < 38 ? at : "top:calc(-30 * var(--u))"};animation-delay:.45s;${media()}`, onclick: open }, vid())));
  }
  // actions
  if (L.actions === "radial") {
    const n = btns.length, span = Math.min(Math.PI * 1.1, Math.PI * 0.21 * (n - 1)), R = (20 + 1.6 * n + G) * D.tap_button.size ** 0.5 * (+root.dataset.uw || 1);
    btns.forEach((b, k) => {
      const ang = toC - span / 2 + span * k / Math.max(1, n - 1), bx = x + Math.cos(ang) * R, by = y + Math.sin(ang) * R * ar;
      add(h("div", { class: "a-rad pop hit" + (b.more ? " more" : ""), title: b.label, style: `left:${bx}%;top:${by}%;animation-delay:${.08 + k * .06}s`, onclick: act(b.a) },
        h("div", { class: "c g" }, svg(b.icon)), L.labels ? h("div", { class: "l" }, b.label) : null));
    });
  }
  if (L.actions === "capsule") {
    const cy = L.tag === "none" ? (above ? `bottom:calc(${100 - y}% + ${13 + G} * var(--u))` : `top:calc(${y}% + ${13 + G} * var(--u))`) : (above ? `bottom:calc(${100 - y}% + ${41.1 + G} * var(--u))` : `top:calc(${y}% + ${41.1 + G} * var(--u))`);
    add(h("div", { class: "a-cap g rise", style: `left:50%;${cy};transform:translateX(-50%);width:calc(84 * var(--u));animation-delay:.12s` },
      h("div", { class: "row" }, ...btns.map((b, k) => h("div", { class: "tib hit pop", style: `animation-delay:${.2 + k * .05}s`, onclick: act(b.a) }, h("span", { class: "i" }, svg(b.icon)), L.labels ? h("span", { class: "l" }, b.label) : null))),
      L.ask === "capsule" ? h("div", { class: "ask hit", onclick: act("ask") }, h("span", { class: "dt" }), h("span", { class: "sp" }, `Ask Azu about ${p.name}…`), h("span", { class: "mi" }, svg("mic")), h("span", { class: "se" }, svg("send"))) : null));
  }
  if (L.tag === "chip" && L.actions === "in_tag") add(h("div", { class: "irow", style: `position:absolute;left:${cx}%;${above ? `bottom:calc(${100 - y}% + ${32.5 + G} * var(--u))` : `top:calc(${y}% + ${32.5 + G} * var(--u))`};transform:translateX(-50%);margin:0` }, ...btns.map(b => h("span", { class: "i hit pop", onclick: act(b.a) }, svg(b.icon)))));
  // screen card
  const sheetH = root.classList.contains("land") ? 0 : L.sheet === "half" ? 46 : L.sheet === "peek" ? (L.actions === "tiles" ? 34 : 22) + (L.ask === "sheet" ? 6 : 0) : 0;
  if (L.actions === "dock") add(h("div", { class: "a-dock rise", style: `bottom:${sheetH ? `${sheetH + 2}%` : "calc(7 * var(--u))"}` }, ...btns.map((b, k) => h("span", { class: "pill g hit", style: `animation-delay:${k * .04}s`, onclick: act(b.a) }, h("span", { class: "i" }, svg(b.icon)), b.label))));
  if (L.sheet !== "none") {
    add(h("div", { class: "s-card rise" },
      h("div", { class: "gr" }), L.sheet === "half" ? h("div", { class: "ban", style: heroStyle(p) }) : null,
      h("span", { class: "cat", style: `background:${col}` }, cat), h("b", {}, p.name), h("p", {}, p.summary || ""),
      L.actions === "tiles" ? h("div", { class: "tiles" }, ...btns.map(b => h("div", { class: "tile hit", onclick: act(b.a) }, h("span", { class: "i" }, svg(b.icon)), b.more ? "More" : b.label))) : null,
      L.ask === "sheet" ? h("div", { class: "ask hit", onclick: act("ask") }, h("span", { class: "dt" }), h("span", { class: "sp" }, "Ask Azu about this place…"), h("span", { class: "mi" }, svg("mic"))) : null,
      h("div", { class: "tcta hit", onclick: open }, "Open the full card", h("span", { class: "i" }, svg("up")))));
  }
  // an action view or a toast on top
  if (tapState.view && tapState.view.p === p) add(actionView(p, tapState.view.a, opts));
  if (tapState.toast && performance.now() - tapState.toastT < 1800) add(h("div", { class: "toast g" }, tapState.toast));
}
function tapAction(p, a, rerender) {
  const now = performance.now();
  if (a === "favourite") { tapState.favs[p.id] = !tapState.favs[p.id]; tapState.toast = tapState.favs[p.id] ? "♥ Saved to your favourites" : "Removed from favourites"; tapState.toastT = now; }
  else if (["card", "pano", "then_now", "model_wall", "model_screen"].includes(a)) tapState.view = { p, a };
  else { const phase = { map: "later (geo-reference)", navigate: "phase D", tour: "phase D", quiz: "phase E", share: "later", play: "uses the media fill", ask: "the Guide tab", more: "a “more” sheet" }[a] || "planned"; tapState.toast = `${a === "more" ? "More" : SHORT[a] || a} · ${phase}`; tapState.toastT = now; }
  rerender && rerender(); if (tapState.toast) setTimeout(() => rerender && rerender(), 1900);
}
function actionView(p, a, opts) {
  const close = h("span", { class: "x hit", onclick: e => { e.stopPropagation(); tapState.view = null; opts.rerender && opts.rerender(); } }, svg("close"));
  const v = h("div", { class: "tv fade hit", onclick: e => e.stopPropagation() });
  if (a === "card") {
    v.style.background = "#F6F3EC"; v.style.color = "#1B1F27";
    v.append(h("div", { style: `height:52%;${heroStyle(p, 0.06)}` }), h("div", { style: "padding:calc(5 * var(--u))" },
      h("span", { class: "cat", style: `font:500 calc(2.4 * var(--u))/1 var(--mono);letter-spacing:.08em;text-transform:uppercase;padding:calc(1.1 * var(--u)) calc(2.2 * var(--u));border-radius:99px;background:${catColor(p)}` }, CATS[p.category]?.label),
      h("b", { style: "display:block;font:600 calc(7.4 * var(--u))/1.05 var(--display);margin:calc(2.4 * var(--u)) 0 calc(1.4 * var(--u))" }, p.name), h("p", { style: "margin:0;font-size:calc(3.2 * var(--u));line-height:1.5;color:#4B5160" }, p.summary || ""),
      ...[70, 92, 84, 60].map(w => h("div", { style: `height:calc(2.2 * var(--u));width:${w}%;border-radius:calc(1 * var(--u));background:#E3DDD1;margin-top:calc(2.6 * var(--u))` })),
      h("p", { style: "font:500 calc(2.4 * var(--u)) var(--mono);color:#8A8F99;margin-top:calc(4 * var(--u))" }, "THE DETAIL CARD (its own Lab) OPENS HERE")), close);
  } else if (a === "pano") {
    const src = p.media?.pano ? null : mediaSource("media_1", 3); const url = p.media?.pano ? PHOTOS[p.media.pano] : src && src.toDataURL ? src.toDataURL() : "";
    let px = 0; const pano = h("div", { class: "pano", style: `background-image:url(${url})` });
    pano.addEventListener("pointerdown", e => { const x0 = e.clientX, p0 = px; pano.setPointerCapture(e.pointerId); const mv = ev => { px = p0 + (ev.clientX - x0); pano.style.backgroundPositionX = px + "px"; }; pano.addEventListener("pointermove", mv); pano.addEventListener("pointerup", () => pano.removeEventListener("pointermove", mv), { once: true }); });
    v.append(pano, h("div", { class: "vt" }, "360° · drag to look around", h("b", {}, p.name + (p.media?.pano ? "" : " · inside (sample)"))), close);
  } else if (a === "then_now") {
    const today = p.media?.today ? `background-image:url(${PHOTOS[p.media.today]});background-size:cover;background-position:center` : null;
    let f = 0.5; const then = h("div", { class: "wipe", style: poiImage(p, 0.12) + ";clip-path:inset(0 50% 0 0)" }), hd = h("div", { class: "handle", style: "left:50%" });
    v.append(today ? h("div", { class: "wipe", style: today }) : h("div", { class: "wipe nophoto" }, h("span", {}, "No “today” photo yet: add one in Specific Marker › Content for actions")), then, hd,
      h("span", { class: "yr", style: "left:4cqw" }, "1700s tiles"), h("span", { class: "yr", style: "right:4cqw" }, "Today"), h("div", { class: "vt" }, "Then & now · drag", h("b", {}, p.name)), close);
    v.addEventListener("pointerdown", e => { v.setPointerCapture(e.pointerId); const mv = ev => { const r = v.getBoundingClientRect(); f = clamp((ev.clientX - r.left) / r.width, 0.02, 0.98); then.style.clipPath = `inset(0 ${(1 - f) * 100}% 0 0)`; hd.style.left = f * 100 + "%"; }; mv(e); v.addEventListener("pointermove", mv); v.addEventListener("pointerup", () => v.removeEventListener("pointermove", mv), { once: true }); });
  } else { // 3D: a preview of phase C
    const img = poiImage(p, 0.04), faces = ["translateZ(calc(20 * var(--u)))", "rotateY(90deg) translateZ(calc(20 * var(--u)))", "rotateY(180deg) translateZ(calc(20 * var(--u)))", "rotateY(-90deg) translateZ(calc(20 * var(--u)))", "rotateX(90deg) translateZ(calc(20 * var(--u)))", "rotateX(-90deg) translateZ(calc(20 * var(--u)))"];
    const moments = p.actions?.model?.moments || [];
    v.style.background = "radial-gradient(circle at 50% 40%, #2A3550, #0B0E14 70%)";
    v.append(h("div", { class: "stage3d" }, h("div", { class: "cube" }, ...faces.map(t => h("div", { style: `transform:${t};${img}` })))),
      h("div", { class: "vt" }, (a === "model_wall" ? "3D on the wall" : "3D on screen") + " · phase C preview", h("b", {}, p.actions?.model?.file || "(no model yet)")),
      h("div", { class: "chipsrow" }, ...["Rotate", "Zoom", ...(p.actions?.model?.controls?.move ? ["Move"] : []), ...moments.map(m => "▶ " + m.name)].map(t => h("span", { class: "pill g", style: "height:calc(8 * var(--u))" }, t))), close);
  }
  return v;
}
