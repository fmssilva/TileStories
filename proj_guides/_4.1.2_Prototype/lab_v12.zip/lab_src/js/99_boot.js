new ResizeObserver(() => { buildDevice(); if (ui.screen === "app") renderPhone(); else renderTapWall(); }).observe(stageEl);
// every editor section starts collapsed (the developer opens what they need)
syncScreens(); renderEditor(); buildDevice(); requestAnimationFrame(loop);
