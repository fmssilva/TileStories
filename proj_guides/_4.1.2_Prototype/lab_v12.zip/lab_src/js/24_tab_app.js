/* ---------- App: the app's screens on a phone (start, onboarding, main AR screen, a tapped POI, the Explore menu) ---------- */
const STEPS = [["start", "1 · Start"], ["onboarding", "2 · Onboarding"], ["main", "3 · Main AR screen"], ["tapped", "4 · A POI tapped"], ["explore", "6 · Explore menu"]];
let phoneEls = null;
const ACT_ICON = { card: "▤", model_wall: "◆", model_screen: "◇", pano: "◎", map: "⌖", then_now: "◐", play: "▶", ask: "✦", navigate: "➜", favourite: "♡", share: "⇪", tour: "⋯", quiz: "?" };

function tapPoiOnPhone(i) {
  if (justDragged) return;
  ui.appPoi = i; ui.appStep = "tapped"; ui.previewLayout = null; ui.compPreview = null; tapState.view = null; ui.tapAnchor = null;
  paintAR(false);   // the camera never moves on a tap: on the device we cannot move the visitor's phone
}
function renderPhone() {
  if (ui.screen !== "app" || !dev.scr) return;
  renderSide(); buildPhone(ui.appStep);
}
function buildPhone(step) {
  const A = D.app, kids = A.theme === "kids", go = st => () => { ui.appStep = st; tapState.view = null; renderPhone(); };
  dev.scr.classList.toggle("kids", kids); dev.scr.classList.toggle("premium", !kids);
  dev.glue.replaceChildren(); phoneEls = null;
  if (step === "start") {
    dev.layer.replaceChildren(h("div", { class: "center", style: kids ? "background:#3E7BD1" : "background:linear-gradient(#0E1424,#1D2B4A)" },
      h("div", { class: "ttl" }, "TileStories"), h("div", { style: "font-size:12px;opacity:.8" }, "Lisbon before 1755, on the tiles"),
      h("div", { class: "bar" }, h("i")), A.start.loading_lines ? h("div", { style: "font-size:11px;opacity:.85;max-width:80%" }, kids ? "Ready? Don't bump your head on the castle!" : "Loading the panorama… mind your head on the 3D.") : null,
      h("span", { class: "cta", onclick: go(A.onboarding.on ? "onboarding" : "main") }, "Start")));
    return;
  }
  if (step === "onboarding") {
    const O = A.onboarding;
    dev.layer.replaceChildren(h("div", { class: "center", style: kids ? "background:#3E7BD1" : "background:linear-gradient(#0E1424,#1D2B4A)" },
      h("div", { class: "ttl", style: "font-size:20px" }, "How do you want to visit?"),
      O.ask_style ? h("div", { style: "width:100%;max-width:340px;display:flex;flex-direction:column;gap:6px" },
        h("div", { class: "opt glass", "aria-pressed": String(!kids), onclick: () => { A.theme = "premium"; renderEditor(); renderPhone(); } }, h("b", {}, "Explorer"), h("br"), "Elegant, calm, more history"),
        h("div", { class: "opt glass", "aria-pressed": String(kids), onclick: () => { A.theme = "kids"; renderEditor(); renderPhone(); } }, h("b", {}, "Family"), h("br"), "Playful, cartoon, games first")) : null,
      O.ask_language ? h("div", { class: "chipz" }, h("span", {}, "English"), h("span", {}, "Português")) : null,
      O.ask_interests ? h("div", { class: "chipz" }, ...["Architecture", "Maritime", "Earthquake", "Royal life"].map(t => h("span", {}, t))) : null,
      h("span", { class: "cta", onclick: go("main") }, "Let's go"), h("span", { style: "font-size:10.5px;opacity:.7;cursor:pointer", onclick: go("main") }, "Skip")));
    return;
  }
  phoneEls = { ph: dev.scr, world: dev.world, layer: dev.layer };
  paintAR(false, step);
}
/* everything that depends on the camera: the wall image, markers, edge arrows, chrome, the tap UI. still = no entry animations (the camera is moving) */
function paintAR(still, stepArg) {
  const E = phoneEls; if (!E || ui.screen !== "app") return;
  const { ph, layer } = E, A = D.app, M = A.main, T = A.tap, kids = A.theme === "kids";
  let step = stepArg || ui.appStep;
  const go = st => () => { if (justDragged) return; ui.appStep = st; tapState.view = null; renderPhone(); };
  applyCam();
  const sel = step === "tapped" ? D.pois[ui.appPoi] : null, L = sel ? tapLayoutOf(sel) : null;   // the preview, else the POI's own style, components and overrides resolved
  let sq = sel ? camProject(sel.pos.x, sel.pos.y) : null;
  const viewOpen = sel && tapState.view?.p === sel;   // an open action view (card, 360, then & now, 3D) fills the screen: moving the phone does not close it
  if (sel && !viewOpen && !onScreen(sq) && T.offscreen === "close" && !ui.camMoving) { ui.appStep = step = "main"; }
  const kids_ = kids ? " kids" : "", out = [];
  D.pois.forEach((p, i) => {
    const q = camProject(p.pos.x, p.pos.y), lv = levelOf(p), isSel = step === "tapped" && p === sel;
    if (!onScreen(q)) return;
    out.push(h("div", { class: "mk", "data-i": i, style: `left:${q.x}%;top:${q.y}%;opacity:${step === "tapped" && !isSel ? .4 : 1}`, onclick: () => tapPoiOnPhone(i) },
      h("div", { class: "dot", style: `background:${catColor(p)}` }), lv?.layers.label !== false && !(isSel && L.tag !== "none") ? h("div", { class: "lbl", style: q.x > 50 ? "left:auto;right:16px" : "" }, p.name) : null));
  });
  if (step === "main" || (step === "tapped" && D.app.pointing.while_tapped)) out.push(...pointers(step === "tapped" ? sel : null));
  if (step === "main") {   // chrome
    const corner = { tl: [], tr: [], bl: [], br: [] };
    const azu = h("div", { class: "fab glass", title: "Ask Azu (the Guide tab)" }, "✦");
    const explore = h("div", { class: "fab wide glass", onclick: go("explore") }, "☰", h("span", { style: "font-size:11px" }, "Explore"));
    const profile = h("div", { class: "fab glass", title: "Profile, preferences, settings" }, "◉");
    const put = (where, el) => { const k = { "top-left": "tl", "top-right": "tr", "bottom-left": "bl", "bottom-right": "br" }[where]; if (k) corner[k].push(el); };
    if (M.ask !== "in-search" && M.ask !== "off") put(M.ask, azu);
    if (M.explore !== "off") put(M.explore, explore);
    if (M.profile !== "in-explore") put(M.profile, profile);
    const search = M.search === "off" ? null : h("div", { class: "search glass" }, h("span", { class: "ic" }, "⌕"), h("span", { style: "flex:1" }, kids ? "Find a place…" : "Search a place or ask…"),
      M.voice ? h("span", { class: "ic" }, "🎙") : null, M.filter ? h("span", { class: "ic" }, "⚲") : null, M.ask === "in-search" ? h("span", { class: "ic" }, "✦") : null);
    out.push(h("div", { class: "topbar" }, h("div", { class: "stack" }, ...corner.tl), M.search === "top" ? search : h("span", { style: "flex:1" }), h("div", { class: "stack" }, ...corner.tr)));
    out.push(h("div", { class: "botbar" }, h("div", { class: "corners" }, h("div", { class: "stack" }, ...corner.bl), h("div", { class: "stack" }, ...corner.br)), M.search === "bottom" ? search : null));
  }
  if (step === "explore") {
    const X = A.explore, Ex = D.experiences;
    out.push(h("div", { class: "sheet2 glass", style: kids ? "" : "background:rgba(16,20,28,.92)" },
      h("div", { style: "display:flex;justify-content:space-between;align-items:center" }, h("b", { style: "font:600 16px var(--display)" }, "Explore the wall"), h("span", { style: "cursor:pointer;opacity:.7", onclick: go("main") }, "✕")),
      X.tours ? [h("h5", {}, "Tours"), ...Ex.tours.map(t => h("div", { class: "it" }, h("span", {}, t.name), h("span", { style: "opacity:.7" }, `${t.theme} · ${t.minutes} min`)))] : null,
      X.games ? [h("h5", {}, "Games"), ...Ex.games.map(g => h("div", { class: "it" }, h("span", {}, g.name), h("span", { style: "opacity:.7" }, g.type)))] : null,
      X.moments ? [h("h5", {}, "Moments on the wall"), ...Ex.moments.map(m => h("div", { class: "it" }, h("span", {}, m.name), h("span", { style: "opacity:.7" }, "▶")))] : null,
      X.layers ? [h("h5", {}, "Wall layers"), h("div", { class: "it" }, h("span", {}, "Today's map"), h("span", { style: "opacity:.7" }, "later"))] : null,
      M.profile === "in-explore" ? [h("h5", {}, "You"), h("div", { class: "it" }, h("span", {}, "Profile, preferences, settings"), h("span", {}, "›"))] : null));
  }
  layer.replaceChildren(...out);
  dev.glue.replaceChildren();
  if (step === "tapped" && ui.compPreview?.type === "buttons") { layer.append(buttonGallery()); ui.tapInfo = "base elements · the buttons"; return; }
  if (step === "tapped" && sel && !ui.camMoving) paintTap(layer, sel, L, { still, rerender: () => paintAR(false), preview: !!(ui.previewLayout || ui.compPreview) });
}
/* Base elements preview: every button in its look, in priority order, with when it shows */
function buttonGallery() {
  const B = D.tap_button, kids = D.app.theme === "kids";
  const tl = h("div", { class: "tapc gal" + (kids ? " kids" : "") + (B.shape === "rounded" ? " b-round" : "") + (B.surface === "solid" ? " b-solid" : ""), style: `--u:${dev.U}px;--bk:${B.size}` });
  tl.append(h("div", { class: "galp g rise" }, h("div", { class: "galh" }, h("b", {}, "Buttons"), h("small", {}, "in priority order · the first ones show, the rest go under more")),
    h("div", { class: "galg" }, ...D.tap_actions.map((a, i) => h("div", { class: "gi" + (a.show === "off" ? " off" : ""), style: `animation-delay:${i * .03}s` },
      h("div", { class: "a-rad st" }, h("div", { class: "c g" }, svg(a.key))), h("span", { class: "gl" }, a.label),
      h("small", {}, a.show === "off" ? "off" : a.show === "always" ? "always" : "if " + (NEEDS[a.key]?.[1] || "content")))))));
  return tl;
}
/* the tap UI of POI sel with layout L: parts on the screen go in `container`, parts on the wall in the glue plane (inside the 3D world) */
function paintTap(container, sel, L, { still = false, rerender, preview = false, id } = {}) {
  const T = D.app.tap, kids = D.app.theme === "kids" ? " kids" : "", P = D.app.pointing;
  let sq = camProject(sel.pos.x, sel.pos.y);
  const viewOpen = tapState.view?.p === sel, on = onScreen(sq);
  // on the wall: the focus is painted on the tiles (0 cm); the tag and the buttons float at the style's distance. The marker dot never moves.
  const W = L.on_wall || {}, focusSel = W.focus ? ".f-ring,.f-pulse" : "", liftSel = [W.tag && ".t-label,.t-chip,.t-card,.t-imm,.t-pan,.irow", W.actions && ".a-rad,.a-cap,.a-dock"].filter(Boolean).join(","), wallSel = [focusSel, liftSel].filter(Boolean).join(",");
  const tl = h("div", { class: "tapc" + kids + (still ? " still" : "") + (PHR > 1 ? " land" : ""), style: `--u:${dev.U}px`, "data-ar": PHR, "data-uw": dev.U / dev.SW * 100 });
  if (id) tl.id = id;
  container.append(tl);
  if (!on && T.offscreen === "pin" && !viewOpen) {
    const e = edgePoint(sq), rot = Math.atan2(sq.y - 50, (sq.x - 50) * PHR) * 180 / Math.PI;
    tl.append(h("div", { class: "pin g hit" + (P.sel_look === "arrow" ? " arrow" : ""), style: `left:${e.x}%;top:${e.y}%`, title: sel.name, onclick: () => camTo(centreOn(sel)) },
      P.sel_look === "arrow" ? null : h("span", { class: "cd", style: `background:${catColor(sel)}` }), P.sel_look === "arrow" ? null : sel.name, h("span", { class: "chev", style: `rotate:${rot}deg` }, svg("chev"))));
  } else {
    if (!on) sq = { x: clamp(sq.x, 8, 92), y: clamp(sq.y, 14, 86) };
    tapUI(tl, sel, sq.x, sq.y, L, { interactive: true, rerender });
    if (wallSel) tl.querySelectorAll(":scope > *").forEach(e => { if (e.matches(wallSel)) e.remove(); });
  }
  if (!viewOpen) ui.tapInfo = (`${levelOf(sel)?.name} · ${L.name}${preview ? " (preview)" : ""} · ${on ? `on screen ${Math.round(sq.x)}%, ${Math.round(sq.y)}%` : "off screen: " + T.offscreen}${wallSel ? ` · on the wall ${L.depth_cm ?? 0} cm` : ""}`);   // shown in the stage's top line, not on the phone
  const poi = on ? sq : null;
  if (dev.scr.isConnected) fitInside(tl, dev.scr, T.keep_inside, poi); else requestAnimationFrame(() => tl.isConnected && fitInside(tl, dev.scr, T.keep_inside, poi));
  if (wallSel && !viewOpen) paintGlue(sel, L, focusSel, liftSel, still, rerender);
  return tl;
}
/* glued parts: laid out once, as the screen was when the POI was tapped (the anchor), then they stay on the wall,
   lifted off it by the layout's distance, and move with it as the phone moves */
function paintGlue(p, L, focusSel, liftSel, still, rerender) {
  let A = ui.tapAnchor; if (!A || A.poi !== p.id) A = ui.tapAnchor = { ...ui.cam, yaw: 0, pitch: 0, poi: p.id };
  const { imgW, imgH } = camSize(), s = imgW / camSize(A).imgW, k = imgW / IW, gw = dev.SW * s, gh = dev.SH * s;
  const q = camProject(p.pos.x, p.pos.y, { ...A, yaw: 0, pitch: 0 });
  dev.glue.replaceChildren();
  const plane = (depthCm, keep, fit) => {   // one plane parallel to the wall, the size of the screen at the anchor
    const dzA = depthCm * PXCM * camSize(A).imgW / IW, fA = dev.P / (dev.P - dzA);   // lifted parts look bigger: shrink them so, from the anchor, they sit where they were laid out
    const g = h("div", { class: "gplane", style: `left:${A.cx * imgW - gw / 2}px;top:${A.cy * imgH - gh / 2}px;width:${gw}px;height:${gh}px;transform:translateZ(${depthCm * PXCM * k}px) rotate(${A.r}deg) scale(${1 / fA})` });
    const gl = h("div", { class: "tapc" + (D.app.theme === "kids" ? " kids" : "") + (still ? " still" : ""), style: `--u:${dev.U * s}px`, "data-ar": PHR, "data-uw": dev.U / dev.SW * 100 });
    g.append(gl); dev.glue.append(g);
    tapUI(gl, p, q.x, q.y, L, { interactive: true, rerender });
    gl.querySelectorAll(":scope > *").forEach(e => { if (!e.matches(keep)) e.remove(); });
    if (fit) {   // measured flat, as on the screen at the anchor
      const wt = dev.world.style.transform, gt = g.style.transform;
      dev.world.style.transform = "none"; g.style.transform = "none";
      fitInside(gl, g, D.app.tap.keep_inside, q);
      dev.world.style.transform = wt; g.style.transform = gt;
    }
  };
  if (focusSel) plane(0, focusSel, false);
  if (liftSel) plane(L.depth_cm ?? 0, liftSel, true);
  if (liftSel && (L.depth_cm ?? 0) > 0)   // a thin needle from the marker on the wall up to the floating parts (seen from the side)
    dev.glue.append(h("div", { class: "needle", style: `left:${p.pos.x * k}px;top:${p.pos.y * k}px;height:${L.depth_cm * PXCM * k}px` }));
}
/* how far a POI is: the turn of the phone (degrees), or the distance on the wall from the point at the screen centre (metres) */
function howFar(p, q) {
  if (D.app.pointing.how_far === "m") { const r = dev.scr.getBoundingClientRect(), c = unproject(r.left + r.width / 2, r.top + r.height / 2); return (Math.hypot(p.pos.x - c.x, p.pos.y - c.y) / PXCM / 100).toFixed(1) + " m"; }
  const dx = (q.x - 50) / 100 * dev.SW, dy = (q.y - 50) / 100 * dev.SH; return Math.round(Math.atan(Math.hypot(dx, dy) / dev.P) * 180 / Math.PI) + "°";
}
/* off-screen pointers to other POIs (App › Pointing): off, all, or the best N by level then by how far you must turn */
function pointers(sel) {
  const P = D.app.pointing; if (P.others === "off") return [];
  const lvIdx = p => Math.max(0, D.levels.indexOf(levelOf(p)));
  let list = D.pois.filter(p => p !== sel && (P.min_level === "any" || lvIdx(p) <= D.levels.findIndex(l => l.key === P.min_level)))
    .map(p => ({ p, q: camProject(p.pos.x, p.pos.y) })).filter(o => !onScreen(o.q)).map(o => ({ ...o, d: Math.hypot(o.q.x - 50, (o.q.y - 50) / PHR) }));
  const byDist = (a, b) => a.d - b.d, byLevel = (a, b) => lvIdx(a.p) - lvIdx(b.p);
  list.sort(P.rank === "distance" ? byDist : P.rank === "level" ? (a, b) => byLevel(a, b) || byDist(a, b) : (a, b) => byLevel(a, b) || byDist(a, b));
  if (P.rank === "level_distance") list.sort((a, b) => byLevel(a, b) || byDist(a, b));
  if (P.others === "top") list = list.slice(0, P.max);
  return list.map(({ p, q, d }) => {
    const e = edgePoint(q), rot = Math.atan2(q.y - 50, (q.x - 50) * PHR) * 180 / Math.PI, far = P.how_far === "off" ? null : h("small", {}, howFar(p, q));
    const arrow = h("span", { class: "chev", style: `rotate:${rot}deg` }, svg("chev"));
    return h("div", { class: `edge ${P.look} glass`, title: p.name, style: `left:${e.x}%;top:${e.y}%;transform:translate(-50%,-50%)`, onclick: () => camTo(centreOn(p)) },
      P.look === "dot" ? h("span", { class: "cd", style: `background:${catColor(p)}` }) : P.look === "arrow" ? arrow : [h("span", { class: "cd", style: `background:${catColor(p)}` }), p.name, far, arrow]);
  });
}
/* after layout: keep the tap UI inside the safe area (status bar above, the screen card or home bar below), move the ring as one group, and move the tag off the buttons */
function fitInside(tl, ph, keepInside = true, poi = null) {
  const pr = ph.getBoundingClientRect(), b = 0, W = pr.width - 2 * b, Hh = pr.height - 2 * b;
  const box = { l: pr.left + b + W * 0.025, r: pr.right - b - W * 0.025, t: pr.top + b + Hh * 0.075, btm: pr.bottom - b - Hh * 0.015 };
  tl.classList.add("measuring");
  const card = tl.querySelector(":scope > .s-card");
  if (card && poi && D.app.tap.card_yields !== false) {   // the POI is under the screen card: tuck the card down to its title so the POI stays visible
    const tr = tl.getBoundingClientRect(), py = tr.top + poi.y / 100 * tr.height;
    const px = tr.left + poi.x / 100 * tr.width, cr = card.getBoundingClientRect(), side = tl.classList.contains("land");
    const uPx = parseFloat(tl.style.getPropertyValue("--u")) || 4;   // landscape: the card also yields when the POI's ring of buttons would reach it
    if (side ? cr.left < px + 40 * uPx : cr.top < py + 24) { card.classList.add("tuck"); card.addEventListener("click", () => card.classList.remove("tuck"), { once: true }); }
  }
  if (card) { const cr = card.getBoundingClientRect(); if (tl.classList.contains("land") && !card.classList.contains("tuck")) box.r = Math.min(box.r, cr.left - 6); else box.btm = Math.min(box.btm, cr.top - 6); }
  const union = els => { const rs = els.map(e => e.getBoundingClientRect()); return { left: Math.min(...rs.map(r => r.left)), right: Math.max(...rs.map(r => r.right)), top: Math.min(...rs.map(r => r.top)), bottom: Math.max(...rs.map(r => r.bottom)) }; };
  const plus = (v, px) => !v ? `${px}px` : v.startsWith("calc(") ? `calc(${v.slice(5, -1)} + ${px}px)` : `calc(${v} + ${px}px)`;
  const shift = (el, dx, dy) => {   // positions may be % or calc(): add the move in px
    if (dx) el.style.left = plus(el.style.left, dx * tl.clientWidth / (tl.getBoundingClientRect().width || 1));
    if (dy) { const k = tl.clientHeight / (tl.getBoundingClientRect().height || 1); if (el.style.bottom) el.style.bottom = plus(el.style.bottom, -dy * k); else el.style.top = plus(el.style.top, dy * k); }
  };
  const into = rc => [rc.left < box.l ? box.l - rc.left : rc.right > box.r ? box.r - rc.right : 0, rc.top < box.t ? box.t - rc.top : rc.bottom > box.btm ? box.btm - rc.bottom : 0];
  const ring = [...tl.querySelectorAll(":scope > .a-rad")];
  const groups = [...tl.querySelectorAll(":scope > .t-label, :scope > .t-chip, :scope > .t-card, :scope > .t-imm, :scope > .a-cap, :scope > .irow, :scope > .t-pan, :scope > .a-dock")].map(el => [el]);
  if (ring.length) groups.push(ring);
  const rectOf = g => g[0].classList.contains("t-pan") ? union([...g[0].children]) : union(g);
  if (keepInside) for (const g of groups) { const [dx, dy] = into(rectOf(g)); if (dx || dy) g.forEach(el => shift(el, dx, dy)); }
  const pin = tl.querySelector(":scope > .pin"); if (pin) { const [dx, dy] = into(pin.getBoundingClientRect()); shift(pin, dx, dy); }   // the pin always stays readable
  // the tag must not sit on the buttons: move it past them, on the side with room, then keep it inside again
  const tag = tl.querySelector(":scope > .t-label, :scope > .t-chip, :scope > .t-card, :scope > .t-imm");
  const btnGroup = ring.length ? ring : [...tl.querySelectorAll(":scope > .a-cap")];
  if (tag && btnGroup.length) {
    const u = union(btnGroup), t = tag.getBoundingClientRect(), hit = Math.min(t.right, u.right) > Math.max(t.left, u.left) && Math.min(t.bottom, u.bottom) > Math.max(t.top, u.top);
    if (hit) {   // candidates: below, above, left, right of the buttons; the first that fits inside and stays off the POI wins
      const th = t.bottom - t.top, tw = t.right - t.left, tr = tl.getBoundingClientRect();
      const P = poi ? { x: tr.left + poi.x / 100 * tr.width, y: tr.top + poi.y / 100 * tr.height } : null;
      const cands = [[t.left, u.bottom + 6], [t.left, u.top - 6 - th], [u.left - 6 - tw, (u.top + u.bottom - th) / 2], [u.right + 6, (u.top + u.bottom - th) / 2]];
      const fits = ([x, y]) => x >= box.l && x + tw <= box.r && y >= box.t && y + th <= box.btm && !(P && P.x > x && P.x < x + tw && P.y > y && P.y < y + th);
      const pick = cands.map(([x, y]) => [clamp(x, box.l, box.r - tw), y]).find(c => fits(c) && !(Math.min(c[0] + tw, u.right) > Math.max(c[0], u.left) && Math.min(c[1] + th, u.bottom) > Math.max(c[1], u.top)))
        || [t.left, box.btm - u.bottom > u.top - box.t ? u.bottom + 6 : u.top - 6 - th];
      tag.style.transform = "none"; tag.style.bottom = ""; tag.style.left = (pick[0] - tr.left) / tr.width * 100 + "%"; tag.style.top = (pick[1] - tr.top) / tr.height * 100 + "%";
      if (keepInside) { const [dx, dy] = into(tag.getBoundingClientRect()); shift(tag, dx, dy); }
    }
  }
  // the tag never sits on the POI: try right, left, above, below the POI; keep the first that fits (inside, off the buttons)
  if (tag && poi) {
    const tr = tl.getBoundingClientRect(), px = tr.left + poi.x / 100 * tr.width, py = tr.top + poi.y / 100 * tr.height, t = tag.getBoundingClientRect();
    if (px > t.left + 2 && px < t.right - 2 && py > t.top + 2 && py < t.bottom - 2) {
      const w = t.width, hh = t.height, gap = 16, u = btnGroup.length ? union(btnGroup) : null;
      const ok = (x, y) => x >= box.l && x + w <= box.r && y >= box.t && y + hh <= box.btm && !(u && Math.min(x + w, u.right) > Math.max(x, u.left) && Math.min(y + hh, u.bottom) > Math.max(y, u.top));
      const cands = [[px + gap, py - hh / 2], [px - gap - w, py - hh / 2], [px - w / 2, py - gap - hh], [px - w / 2, py + gap]].map(([x, y]) => [clamp(x, box.l, box.r - w), clamp(y, box.t, box.btm - hh)]);
      const best = cands.find(([x, y]) => ok(x, y) && !(px > x && px < x + w && py > y && py < y + hh)) || cands.find(([x, y]) => !(px > x && px < x + w && py > y && py < y + hh));
      if (best) { tag.style.transform = "none"; tag.style.bottom = ""; tag.style.left = (best[0] - tr.left) / tr.width * 100 + "%"; tag.style.top = (best[1] - tr.top) / tr.height * 100 + "%"; }
    }
  }
  tl.classList.remove("measuring");
}

let demoTimer = 0;
function demoLayout(key) {   // the main screen, a finger taps the marker (the camera first brings it into view), then the layout opens
  clearTimeout(demoTimer); ui.compPreview = null; ui.previewLayout = key; tapState.view = null; ui.appStep = "main"; setScreen("app"); renderPhone();
  const p = D.pois[ui.appPoi], go = () => {
    const q = camProject(p.pos.x, p.pos.y), layer = phoneEls.layer;
    if (!layer || !onScreen(q)) { ui.appStep = "tapped"; paintAR(false); return; }
    layer.append(h("div", { class: "finger", style: `left:${q.x}%;top:${q.y}%` }), h("div", { class: "tapfx", style: `left:${q.x}%;top:${q.y}%` }));
    demoTimer = setTimeout(() => { const keep = ui.previewLayout; tapPoiOnPhone(ui.appPoi); ui.previewLayout = keep; paintAR(false); }, 750);
  };
  const q = camProject(p.pos.x, p.pos.y); if (onScreen(q) && q.x > 8 && q.x < 92 && q.y > 10 && q.y < 85) go(); else camTo(centreOn(p), 450, go);
}
const usedTap = key => (D.app.tap.default_layout === key ? 1 : 0) + D.levels.filter(l => l.tap_layout === key).length + D.pois.filter(p => p.on_tap?.tap_layout === key).length;
const usedComp = (field, key) => D.tap_layouts.filter(s => s[field] === key).length + D.pois.filter(p => p.on_tap?.over?.[field] === key).length;
function newKey(list, prefix) { let n = 1; while (list.find(t => t.key === prefix + n)) n++; return prefix + n; }
/* Unity's ReorderableList: one foldout per element, edited in place; the + adds at the end */
function listElement(id, title, sub, list, i, onDemo, body, opts = {}) {
  const it = list[i], used = opts.used ? opts.used(it.key) : 0;
  const btns = h("span", { style: "display:flex;gap:3px;align-items:center" },
    used ? h("span", { class: "sub", style: "margin-right:4px" }, `used by ${used}`) : null,
    onDemo ? h("button", { class: "ib", title: "Play the demo", onclick: () => onDemo(it) }, "▶") : null,
    h("button", { class: "ib", title: "Move up", disabled: i === 0, onclick: () => { snap(); list.splice(i - 1, 0, list.splice(i, 1)[0]); changed(); } }, "↑"),
    h("button", { class: "ib", title: "Duplicate", onclick: () => { snap(); const c = clone(it); c.key = newKey(list, opts.prefix); c.name = it.name + " copy"; list.splice(i + 1, 0, c); ui.open[id.replace(it.key, c.key)] = true; changed(); onDemo && onDemo(c); } }, "⧉"),
    h("button", { class: "ib", title: used ? "In use: pick another one there first" : "Remove", disabled: used > 0, onclick: () => { snap(); list.splice(i, 1); changed(); } }, "−"));
  return fold(id, title, { color: "#F2C14E", sub, extra: btns, screen: opts.screen, step: opts.step, onToggle: o => { if (o && onDemo) onDemo(it); } }, body);
}
function tapLayoutsBody() {
  const out = [h("p", { class: "guide" }, "A style puts the components together: focus, a tag component, an action component, the screen card and the ask field, and how they sit around the marker. Open one: the phone plays it (▶ replays).")];
  D.tap_layouts.forEach((L, i) => {
    const prev = () => { ui.previewLayout = L.key; ui.appStep = "tapped"; tapState.view = null; ui.tapAnchor = null; };
    const sel = (key, opts) => id => h("select", { id, onchange: e => { snap(); L[key] = e.target.value; prev(); changed(); } }, opts.map(([v, t]) => h("option", { value: v, selected: L[key] === v }, t)));
    const T = tagComp(L.tag), A = actComp(L.actions);
    out.push(listElement("tapL_" + L.key, L.name, tapSummary(L), D.tap_layouts, i, x => demoLayout(x.key), () => [
      ...row("Name", fText(L, "name")),
      ...row("Focus", sel("focus", TAP_OPTS.focus)),
      ...row("Tag", sel("tag", [["none", "None"], ...D.tap_tags.map(t => [t.key, t.name])])),
      ...(T && T.kind !== "panel" ? row("Tag placement", sel("place", TAP_OPTS.place), null, true) : []),
      ...row("Actions", sel("actions", [["none", "None"], ...D.tap_action_comps.map(t => [t.key, t.name])])),
      ...row("Distance to the marker", id => { const f = fRange(L, "gap", 0, 20, 1)(id); f.addEventListener("input", () => { prev(); renderPhone(); }); return f; }, "How far the tag and the buttons sit from the marker, in phone units (0 = right next to it). A POI can override it: a big marker or a 3D model needs more room."),
      h("div", { class: "grp" }, "Screen or wall", h("span", {}, "glued parts stay on the wall as the phone moves")),
      ...["focus", "tag", "actions"].map(k => row(`${k[0].toUpperCase() + k.slice(1)} on the wall`, id => h("input", { id, type: "checkbox", checked: !!L.on_wall?.[k], style: "justify-self:start", onchange: e => { snap(); L.on_wall = { ...(L.on_wall || {}), [k]: e.target.checked }; prev(); changed(); } }),
        k === "focus" ? "On the wall, the ring sits on the POI and you see it from the side when you walk around. Spotlight always dims the whole screen." : k === "tag" ? "Off: the tag is drawn on the screen next to the POI and follows it. On: the tag is placed once, when the POI is tapped, and then stays in the world, lifted off the wall by the distance below." : "Same for the action buttons.")).flat(),
      ...(L.on_wall && (L.on_wall.focus || L.on_wall.tag || L.on_wall.actions) ? row("Distance from the wall", id => { const f = fRange(L, "depth_cm", 0, 40, 1, " cm")(id); f.addEventListener("input", () => { prev(); renderPhone(); }); return f; }, "How far in front of the tiles the glued parts float. 0 = painted on the wall. Walk to the side (Alt + drag) to see the gap.", true) : []),
      h("div", { class: "grp" }, "On the screen", h("span", {}, "these never go on the wall")),
      ...row("Screen card", sel("sheet", TAP_OPTS.sheet)),
      ...row("Ask field", sel("ask", TAP_OPTS.ask)),
      ...(A?.kind === "tiles" && L.sheet === "none" ? [h("div", { class: "notice" }, "Tiles live in the screen card: pick a screen card.")] : []),
      ...(A?.kind === "in_tag" && !["card", "immersive", "panel", "chip"].includes(T?.kind) ? [h("div", { class: "notice" }, "“Links in the tag” needs a chip, card, immersive card or panel tag.")] : []),
    ], { used: usedTap, prefix: "tap_layout_", screen: "app", step: "tapped" }));
  });
  out.push(h("div", { class: "addrow", style: "justify-content:flex-end" }, h("button", { class: "ubtn", style: "flex:0 0 auto", onclick: () => { snap(); const key = newKey(D.tap_layouts, "tap_layout_"); D.tap_layouts.push({ key, name: "New style", focus: "ring", tag: "tag_comp_2", place: "auto", actions: "act_comp_2", sheet: "none", ask: "off", on_wall: { ...SCREEN }, depth_cm: 8, gap: 0 }); ui.open["tapL_" + key] = true; changed(); demoLayout(key); } }, "+ Add style")));
  return out;
}
/* base elements: every action button in priority order (the first ones show, the rest go under "more"), and the button look */
function tapBaseBody() {
  const preview = () => { ui.previewLayout = null; ui.compPreview = { type: "buttons" }; ui.appStep = "tapped"; tapState.view = null; renderPhone(); };
  const rows = D.tap_actions.map((a, i) => h("div", { class: "brow" + (a.show === "off" ? " off" : "") },
    h("button", { class: "ib", title: "Move up (earlier = shown first)", disabled: i === 0, onclick: () => { snap(); D.tap_actions.splice(i - 1, 0, D.tap_actions.splice(i, 1)[0]); changed(); preview(); } }, "↑"),
    h("span", { class: "bi" }, svg(a.key)),
    h("input", { class: "uin", value: a.label, "aria-label": "Button label", onchange: e => { const v = e.target.value.trim(); if (!v) return; snap(); a.label = v; changed(); preview(); } }),
    h("select", { "aria-label": a.label + " shows", onchange: e => { snap(); a.show = e.target.value; changed(); preview(); } },
      [["auto", NEEDS[a.key] ? `When the POI has ${NEEDS[a.key][1]}` : "Auto"], ["always", "Always"], ["off", "Off"]].filter(([v]) => v !== "auto" || NEEDS[a.key]).map(([v, t]) => h("option", { value: v, selected: a.show === v }, t))),
    h("small", { class: "bk" }, ACTIONS[a.key]?.label || "")));
  const B = D.tap_button;
  return [h("p", { class: "guide" }, "One line per action type (the types are framework code). Order = priority: a component shows the first ones and puts the rest under “more”. “When the POI has …” hides the button on POIs without that content; a POI can still hide or force one."),
    h("div", { class: "blist" }, ...rows),
    h("div", { class: "grp" }, "Button look", h("span", {}, "shared by every action component")),
    ...row("Size", id => { const f = fRange(B, "size", 0.8, 1.3, 0.05, "×")(id); f.addEventListener("input", preview); return f; }),
    ...row("Shape", fSelect(B, "shape", [["circle", "Circle"], ["rounded", "Rounded square"]], preview)),
    ...row("Surface", fSelect(B, "surface", [["glass", "Glass (blurred)"], ["solid", "Solid light"]], preview))];
}
function tagCompsBody() {
  const out = [h("p", { class: "guide" }, "Finished tags, ready to use in a style. What each shows is set here once.")];
  D.tap_tags.forEach((T, i) => {
    const demo = () => { clearTimeout(demoTimer); ui.previewLayout = null; ui.compPreview = { type: "tag", key: T.key }; ui.appStep = "tapped"; tapState.view = null; renderPhone(); };
    const sub = [TAP_OPTS.tag_kind.find(k => k[0] === T.kind)?.[1].split(" (")[0], T.kind === "immersive" ? "size " + (T.size || "M") : null, T.media && T.kind !== "label" && T.kind !== "chip" ? T.media : null].filter(Boolean).join(" · ");
    out.push(listElement("tagc_" + T.key, T.name, sub, D.tap_tags, i, demo, () => [
      ...row("Name", fText(T, "name")),
      ...row("Kind", fSelect(T, "kind", TAP_OPTS.tag_kind, demo)),
      ...(T.kind === "immersive" ? row("Size", fSelect(T, "size", [["S", "Small"], ["M", "Medium"], ["L", "Large"]], demo), null, true) : []),
      ...(["card", "immersive", "panel"].includes(T.kind) ? row("Picture", fSelect(T, "media", [["image", "Photo"], ["video", "Video (loops, muted)"], ["none", "None"]], demo), "Photo: the POI's hero photo. Video: the POI's clip, looping and muted (here: the photo with a play badge). None: text only.", true) : []),
      ...(T.kind !== "label" ? [...row("Category", fToggle(T, "show_cat"), null, true), ...row("One-line summary", fToggle(T, "show_summary"), null, true)] : []),
    ], { used: k => usedComp("tag", k), prefix: "tag_comp_", screen: "app", step: "tapped" }));
  });
  out.push(h("div", { class: "addrow", style: "justify-content:flex-end" }, h("button", { class: "ubtn", style: "flex:0 0 auto", onclick: () => { snap(); const key = newKey(D.tap_tags, "tag_comp_"); D.tap_tags.push({ key, name: "New tag", kind: "chip", show_cat: true, show_summary: true }); ui.open["tagc_" + key] = true; changed(); } }, "+ Add tag component")));
  return out;
}
function actCompsBody() {
  const out = [h("p", { class: "guide" }, "Finished button groups, ready to use in a style. The buttons themselves come from Base elements.")];
  D.tap_action_comps.forEach((A, i) => {
    const demo = () => { clearTimeout(demoTimer); ui.previewLayout = null; ui.compPreview = { type: "act", key: A.key }; ui.appStep = "tapped"; tapState.view = null; renderPhone(); };
    out.push(listElement("actc_" + A.key, A.name, `${TAP_OPTS.act_kind.find(k => k[0] === A.kind)?.[1]} · up to ${A.max}${A.labels ? " · labels" : ""}`, D.tap_action_comps, i, demo, () => [
      ...row("Name", fText(A, "name")),
      ...row("Kind", fSelect(A, "kind", TAP_OPTS.act_kind, demo)),
      ...row("At most", id => { const f = fRange(A, "max", 1, 8, 1)(id); f.addEventListener("change", demo); return f; }, "The rest go under “more”."),
      ...row("Labels under the icons", fToggle(A, "labels")),
    ], { used: k => usedComp("actions", k), prefix: "act_comp_", screen: "app", step: "tapped" }));
  });
  out.push(h("div", { class: "addrow", style: "justify-content:flex-end" }, h("button", { class: "ubtn", style: "flex:0 0 auto", onclick: () => { snap(); const key = newKey(D.tap_action_comps, "act_comp_"); D.tap_action_comps.push({ key, name: "New buttons", kind: "capsule", max: 4, labels: true }); ui.open["actc_" + key] = true; changed(); } }, "+ Add action component")));
  return out;
}
function appTab() {
  const A = D.app, M = A.main, O = A.onboarding, X = A.explore;
  const sec = (key, title, step, body, opts = {}) => fold(key, title, Object.assign({ color: "#F2C27A", screen: "app", step }, opts), body);
  const POS = [["top-left", "Top left"], ["top-right", "Top right"], ["bottom-left", "Bottom left"], ["bottom-right", "Bottom right"]];
  return [
    h("p", { class: "lab-intro" }, h("b", {}, "App · the screens around the wall. "), "Compose the app's own screens: what a visitor sees before the camera, the main AR screen's buttons, and what a tap on a POI shows. The phone on the left follows every change; click a section to open its screen. Looks and content still come from Global Scene and Specific Marker; Azu's behaviour from the Guide tab."),
    sec("app_start", "1 · Start", "start", () => [...row("Loading lines", fToggle(A.start, "loading_lines")), h("p", { class: "guide" }, "Splash, download of the wall's media on first launch (parked), friendly loading lines instead of a spinner.")]),
    sec("app_onb", "2 · Onboarding", "onboarding", () => [...row("Show onboarding", fToggle(O, "on")), ...(O.on ? [...row("Ask the look (Explorer / Family)", fToggle(O, "ask_style"), null, true), ...row("Ask the language", fToggle(O, "ask_language"), null, true), ...row("Ask interests (topic lenses)", fToggle(O, "ask_interests"), null, true)] : []),
      h("p", { class: "guide" }, "One screen, skippable. The audiences and topic lenses are the Detail Card's Audiences (_3.5).")]),
    sec("app_main", "3 · Main AR screen", "main", () => [
      ...row("Search", fSelect(M, "search", [["bottom", "Bar at the bottom"], ["top", "Bar at the top"], ["off", "Off"]])),
      ...(M.search !== "off" ? [...row("Voice in search", fToggle(M, "voice"), null, true), ...row("Filter button", fToggle(M, "filter"), null, true)] : []),
      ...row("Ask Azu button", fSelect(M, "ask", [...POS, ["in-search", "Inside the search bar"], ["off", "Off"]])),
      ...row("Explore button", fSelect(M, "explore", [...POS, ["off", "Off"]])),
      ...row("Profile & settings", fSelect(M, "profile", [...POS, ["in-explore", "Inside the Explore menu"]])),
      h("p", { class: "guide" }, "The wall itself (points, regions, tags, Wall Life) comes from Global Scene and each POI. Off-screen POIs: see Pointing.")]),
    sec("app_point", "4 · Pointing · off-screen POIs", "main", () => { const P = A.pointing, re = () => { renderPhone(); }; return [
      h("div", { class: "grp" }, "The selected POI", h("span", {}, "after a tap, when the phone turns away")),
      ...row("When it leaves the screen", fSelect(A.tap, "offscreen", [["pin", "A pointer at the edge"], ["close", "Close the tap UI"], ["keep", "Keep the tap UI, clamped inside"]], re), "pointer: a small chip at the screen edge points back to the POI; tap it to turn back. close: back to the main screen. keep: the tag stays, pushed inside the screen."),
      ...(A.tap.offscreen === "pin" ? row("Its pointer", fSelect(P, "sel_look", [["chip", "Name + arrow"], ["arrow", "Arrow only"]], re), null, true) : []),
      ...row("Keep other pointers while a POI is open", fToggle(P, "while_tapped")),
      h("div", { class: "grp" }, "Other POIs", h("span", {}, "on the main AR screen")),
      ...row("Point to", fSelect(P, "others", [["off", "None"], ["top", "The best few"], ["all", "All of them"]], re)),
      ...(P.others === "top" ? row("How many", fRange(P, "max", 1, 8, 1), null, true) : []),
      ...(P.others !== "off" ? [
        ...row("Pick by", fSelect(P, "rank", [["level_distance", "Level first, then the nearest"], ["distance", "The nearest (least turning)"], ["level", "Level only"]], re), "Level = the POI's hierarchy level (Global Scene › Levels, top = most important). Nearest = how far you must turn the phone to see it.", true),
        ...row("Only from level", fSelect(P, "min_level", [["any", "Any level"], ...D.levels.map(l => [l.key, l.name + " and above"])], re), null, true),
        ...row("Look", fSelect(P, "look", [["chip", "Name + arrow"], ["arrow", "Arrow"], ["dot", "Coloured dot"]], re), null, true),
        ...(P.look === "chip" ? row("Show how far", fSelect(P, "how_far", [["off", "No"], ["deg", "Degrees to turn the phone"], ["m", "Metres on the wall"]], re), "Degrees: how much the visitor must turn the phone. Metres: the distance on the wall from the point at the centre of the screen to the POI.", true) : [])] : []),
      h("p", { class: "guide" }, "Turn the phone away from a POI (drag the picture) to see the pointers. Later: the next stop of a tour, unseen POIs first.")]; }),
    sec("app_tap", "5 · On tap", "tapped", () => [
      ...row("Default style for the whole app", fSelect(A.tap, "default_layout", D.tap_layouts.map(t => [t.key, t.name]), () => { ui.previewLayout = null; renderPhone(); }), "Every POI uses this style unless its level (Global Scene › Levels › On tap) or the POI itself (Specific Marker › On tap) picks another; a POI can also override single fields."),
      fold("tap_base", "Base elements", { color: "#9FD7C1", screen: "app", step: "tapped", onToggle: o => { ui.compPreview = o ? { type: "buttons" } : null; renderPhone(); }, sub: `${D.tap_actions.filter(a => a.show !== "off").length} buttons · button look` }, tapBaseBody),
      fold("tap_tags", "Tag components", { color: "#9FD7C1", screen: "app", step: "tapped", onToggle: o => { ui.compPreview = o ? { type: "tag", key: D.tap_tags[0]?.key } : null; ui.previewLayout = null; renderPhone(); }, sub: D.tap_tags.map(t => t.name).join(" · ") }, tagCompsBody),
      fold("tap_acts", "Action components", { color: "#9FD7C1", screen: "app", step: "tapped", onToggle: o => { ui.compPreview = o ? { type: "act", key: D.tap_action_comps[0]?.key } : null; ui.previewLayout = null; renderPhone(); }, sub: D.tap_action_comps.map(t => t.name).join(" · ") }, actCompsBody),
      fold("tap_styles", "On-tap styles", { color: "#F2C14E", screen: "app", step: "tapped", onToggle: () => { ui.compPreview = null; renderPhone(); }, sub: "the compositions" }, tapLayoutsBody),
      h("div", { class: "grp" }, "When the phone moves", h("span", {}, "safe area, screen card")),
      ...row("Screen card makes way for the POI", fToggle(A.tap, "card_yields"), "When the POI ends up under the screen card, the card tucks down to its title; tap it to open it again."),
      ...row("Keep the tap UI inside the screen", fToggle(A.tap, "keep_inside"), "After layout, every part is moved inside the safe area: below the status bar, above the home bar or the screen card. The ring moves as one group; the tag always moves off the buttons and off the POI."),
      h("p", { class: "guide" }, "A tap never moves the camera: the tap UI opens around the POI where it is. Scroll = walk closer / further, drag = look around, Alt + drag = walk around, Shift + scroll = tilt. When the selected POI leaves the screen: see Pointing.")]),
    sec("app_exp", "6 · Explore menu", "explore", () => [
      ...row("Tours", fToggle(X, "tours")), ...row("Games", fToggle(X, "games")), ...row("Moments on the wall", fToggle(X, "moments")), ...row("Wall layers", fToggle(X, "layers")),
      h("p", { class: "guide" }, "The wall-level features. Their content lives in the Experiences tab.")]),
    sec("app_look", "7 · Look", "main", () => [...row("Look", fSelect(A, "theme", [["premium", "Explorer (premium)"], ["kids", "Family (cartoon)"]])),
      h("p", { class: "guide" }, "Two looks from the same screens: design tokens per audience (_3.5 §3.5), not a second design. The visitor picks it in onboarding.")]),
  ];
}

/* ---------- placeholders for planned features (a card: purpose, configs, phase) ---------- */
