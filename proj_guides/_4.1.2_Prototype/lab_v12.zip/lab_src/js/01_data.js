/* ---------- data (what config.json holds) ---------- */
const CATS = {
  category_1: { label: "Royal Government", color: "#FFC786" },
  category_2: { label: "Religious", color: "#CB80FF" },
  category_6: { label: "Infrastructure", color: "#9DDEFF" },
};
function mkStyle(key, label, o = {}) {
  const base = {
    key, label,
    line: { width_cm: 1.2, min_px: 1.5, max_px: 6, color_mode: "category", color: "#FFFFFF", opacity: 0.95, pattern: "solid", dash_cm: 3, gap_cm: 2,
            placement: "outside", offset_cm: 1.5, glow: true, glow_width_cm: 3, glow_intensity: 0.6, double: false, double_gap_cm: 1.5 },
    vertices: { show_at: "corners", mark: "bracket", size_cm: 4, color_mode: "line", color: "#FFFFFF" },
    fill: { mode: "tint", color_mode: "category", color: "#FFFFFF", opacity: 0.14, feather_cm: 2,
            grad: "radial", angle_deg: 90, alpha_from: 0.3, alpha_to: 0, pattern: "azulejo", scale_cm: 6, fit: "cover", media_play: "loop" },
    motion: { intro: { preset: "build", duration_s: 1.6, segment_delay_s: 0.12, direction: "cw" },
              idle: { preset: "comet", period_s: 5, count: 1, intensity: 0.7 },
              focus: { preset: "spotlight", amount: 0.55, duration_s: 0.6 } },
  };
  for (const [part, vals] of Object.entries(o)) {
    if (part === "motion") for (const [ph, v] of Object.entries(vals)) Object.assign(base.motion[ph], v);
    else Object.assign(base[part], vals);
  }
  return base;
}
const K = (x, y, corner = "", radius = 6) => ({ x, y, corner, radius });
function mkContent(kind, key, name, anchor, o = {}) {
  const k = KINDS[kind];
  return Object.assign({ key, name, kind, anchor, trigger: k.trig, delay_s: 0, every_min_s: 6, every_max_s: 12, reduce: "", p: clone(k.p) }, o, { p: Object.assign(clone(k.p), o.p || {}) });
}
const KINDS = {
  repaint:   { code: "K1", label: "Repaint", lives: "On the wall surface, covering a shape", made: "Painted wall canvas (Krita / Photoshop / AI style over the exported canvas) + a reveal shader (wipe, paint-on brush): “art comes alive”", prec: "high", anchor: "polygon", trig: "reveal", trigs: ["reveal", "loop", "focus", "unfocus", "lapse"],
               p: { look: "night", reveal: "brush", wipe_s: 2.4, feather_cm: 2, strength: 0.9 } },
  flat:      { code: "K2", label: "Flat animation", lives: "On the wall surface, inside a shape", made: "PSD layers → PSD Importer + 2D Animation (bones); or a flipbook / a video with alpha", prec: "medium", anchor: "polygon", trig: "loop", trigs: ["loop", "reveal", "focus", "every"],
               p: { subject: "curtain", color: "#F3E6C8", amp_cm: 1.2, speed: 1, cover: true } },
  hinged:    { code: "K3", label: "Hinged 3D piece", lives: "Out of the wall, starting flush", made: "ProBuilder slab cut to the shape, pivot on the hinge, wall-projection material; Animation window", prec: "high", anchor: "polygon", trig: "focus", trigs: ["focus", "reveal", "every"],
               p: { angle_deg: 70, dur_s: 0.9, interior: true, close_on_unfocus: true } },
  agent:     { code: "K4", label: "Agent on a path", lives: "In front of the wall, moving", made: "Any prefab (2D flipbook or 3D model) + Splines' Spline Animate on a Path shape", prec: "low", anchor: "path", trig: "every", trigs: ["every", "loop", "focus"],
               p: { sprite: "tram", size_cm: 6, speed_cm_s: 22 } },
  particles: { code: "K5", label: "Ambient particles", lives: "In front of the wall or in the sky", made: "Particle System; the emitter is a shape or a box", prec: "low", anchor: "any", trig: "every", trigs: ["every", "loop", "focus"],
               p: { sprite: "birds", count: 7, speed_cm_s: 30 } },
  guest:     { code: "K6", label: "Screen guest", lives: "On the screen, not in the world", made: "UI Toolkit (or uGUI) with a flipbook, a 2D rig or Rive", prec: "none", anchor: "screen", trig: "every", trigs: ["every"],
               p: { edge: "right", stay_s: 2.5, hide_on_card: true } },
};
const TRIGS = { reveal: "Reveal (once, when the POI appears)", loop: "Loop (always while visible)", focus: "Focus (on tap; back on close)", unfocus: "Unfocus (when the card closes)", every: "Every N–M s (random)", lapse: "Lapse (time period changes) · later" };

let D = {
  styles: [
    mkStyle("region_style_1", "Facade"),
    mkStyle("region_style_2", "Detail", { line: { width_cm: 0.6, color_mode: "fixed", color: "#FFFFFF", placement: "edge", offset_cm: 0, glow: false },
      vertices: { show_at: "none" }, fill: { opacity: 0.1 },
      motion: { intro: { preset: "draw_on", duration_s: 1.0 }, idle: { preset: "breathe", period_s: 3.5, intensity: 0.6 }, focus: { preset: "brighten", amount: 1.8 } } }),
    mkStyle("region_style_3", "Windows", { vertices: { show_at: "all", mark: "ring", size_cm: 3, color_mode: "fixed", color: "#FFE9A8" }, fill: { mode: "none" },
      motion: { intro: { preset: "build", segment_delay_s: 0.15 }, idle: { preset: "knot_pulse", period_s: 2.4, intensity: 0.8 }, focus: { preset: "brighten", amount: 1.6 } } }),
    mkStyle("region_style_4", "Street", { line: { width_cm: 1.4, pattern: "dashed", dash_cm: 3, gap_cm: 2, placement: "edge", offset_cm: 0, glow: true, glow_intensity: 0.4 },
      vertices: { show_at: "none" }, fill: { mode: "none" },
      motion: { intro: { preset: "draw_on", duration_s: 1.4 }, idle: { preset: "flow", period_s: 1.6, intensity: 0.7 }, focus: { preset: "lock_on", amount: 1.4, duration_s: 0.5 } } }),
    mkStyle("region_style_5", "Glow wash", { line: { width_cm: 0.8, offset_cm: 1, glow: true, glow_width_cm: 4, glow_intensity: 0.5 },
      vertices: { show_at: "none" }, fill: { mode: "gradient", grad: "radial", alpha_from: 0.32, alpha_to: 0, feather_cm: 3 },
      motion: { intro: { preset: "fade", duration_s: 1.2 }, idle: { preset: "sweep", period_s: 6, intensity: 0.6 }, focus: { preset: "brighten", amount: 1.6 } } }),
    mkStyle("region_style_6", "Media window", { line: { width_cm: 0.6, color_mode: "fixed", color: "#FFF3D6", offset_cm: 0, glow: true, glow_width_cm: 2, glow_intensity: 0.4 },
      vertices: { show_at: "none" }, fill: { mode: "media", opacity: 0.92, feather_cm: 1, fit: "cover" },
      motion: { intro: { preset: "fade", duration_s: 1.0 }, idle: { preset: "none" }, focus: { preset: "brighten", amount: 1.6 } } }),
    mkStyle("region_style_7", "Quiet (appears on tap)", { line: { width_cm: 0.7, color_mode: "fixed", color: "#FFE9A8", opacity: 0, offset_cm: 0.5, glow: true, glow_width_cm: 2, glow_intensity: 0.6 },
      vertices: { show_at: "none" }, fill: { mode: "none" },
      motion: { intro: { preset: "fade", duration_s: 0.6 }, idle: { preset: "none" }, focus: { preset: "appear", amount: 0.9, duration_s: 0.5 } } }),
  ],
  region_default: "region_style_1",   // the app-wide region style; a level or a POI may pick another
  levels: [
    { key: "level_1", name: "Hub", layers: { point: true, region: true, label: true, tag: false, model: false }, region_style: "region_style_1", tap_layout: "tap_layout_2", reveal_delay_s: 0 },
    { key: "level_2", name: "Landmark", layers: { point: false, region: true, label: true, tag: false, model: false }, region_style: "region_style_1", tap_layout: "tap_layout_3", reveal_delay_s: 0.4 },
    { key: "level_3", name: "Detail", layers: { point: true, region: false, label: true, tag: false, model: false }, region_style: "region_style_2", tap_layout: "tap_layout_1", reveal_delay_s: 0.8 },
  ],
  pois: [
    { id: "twin_tower_church", name: "Twin-tower church", category: "category_2", level: "level_1", media: { hero: "castle_walls", pano: "castle_walls", sample: true }, pos: { x: 536, y: 300 }, summary: "A baroque church on the river square, lost in 1755.",
      world: { presence_override: "", style_override: "", shapes: [
        { key: "shape_1", name: "Outline", type: "polygon", style: "", default_corner: "sharp", knots: [K(507,378),K(507,282),K(517,256),K(528,282),K(529,300),K(545,309),K(557,300),K(559,288),K(566,268),K(574,288),K(575,304),K(620,299),K(628,330),K(628,378)] },
        { key: "shape_2", name: "Door", type: "polygon", style: "region_style_6", media: "media_1", default_corner: "sharp", knots: [K(525,362),K(525,342),K(534,334,"smooth"),K(543,342),K(543,362)] },
        { key: "shape_3", name: "Windows", type: "points", style: "region_style_3", default_corner: "sharp", knots: [K(533,321),K(517,322),K(566,322),K(590,332),K(605,332)] },
        { key: "shape_4", name: "Cornice", type: "path", style: "region_style_2", default_corner: "sharp", knots: [K(575,304),K(620,299)] },
        { key: "shape_5", name: "Tower window", type: "polygon", style: "region_style_7", default_corner: "sharp", knots: [K(511,300),K(524,300),K(524,318),K(511,318)] },
      ], content: [
        mkContent("repaint", "content_1", "Night facade", "shape_1"),
        mkContent("flat", "content_2", "Curtain", "shape_5"),
      ] } },
    { id: "domed_church", name: "Domed church", category: "category_2", level: "level_2", media: { hero: "castle_night", pano: "castle_walls", sample: true }, pos: { x: 579, y: 124 }, summary: "Its dome watched over the upper town.",
      world: { presence_override: "", style_override: "region_style_5", shapes: [
        { key: "shape_1", name: "Outline", type: "polygon", style: "", default_corner: "sharp", knots: [K(565,156),K(565,126),K(571,116,"smooth"),K(579,110,"smooth"),K(587,116,"smooth"),K(592,126),K(592,136),K(608,136),K(613,150),K(609,157)] },
        { key: "shape_2", name: "Window", type: "polygon", style: "region_style_7", default_corner: "sharp", knots: [K(573,123),K(586,123),K(586,140),K(573,140)] },
      ], content: [
        mkContent("hinged", "content_1", "Shutters", "shape_2"),
      ] } },
    { id: "arched_gate", name: "Arched gate", category: "category_6", level: "level_3", media: { hero: "castle_day", pano: "castle_walls", sample: true }, pos: { x: 267, y: 356 }, summary: "Where goods came up from the river.",
      world: { presence_override: "both", style_override: "", shapes: [
        { key: "shape_1", name: "Riverside road", type: "path", style: "region_style_4", default_corner: "smooth", knots: [K(120,399),K(230,395),K(330,393),K(440,398)] },
      ], content: [
        mkContent("agent", "content_1", "Tram", "shape_1", { every_min_s: 5, every_max_s: 10 }),
      ] } },
    { id: "castle_hill", name: "Castle hill", on_tap: { tap_layout: "", over: { gap: 6, buttons: { favourite: "hide" } } }, category: "category_1", level: "level_2", pos: { x: 252, y: 178 }, summary: "Sample media: today's photos of São Jorge Castle stand in for this hilltop.",
      media: { hero: "castle_day", today: "castle_day", pano: "castle_walls", night: "castle_night" },
      world: { presence_override: "", style_override: "", shapes: [
        { key: "shape_1", name: "Outline", type: "polygon", style: "", default_corner: "sharp", knots: [K(220,204),K(220,156),K(228,146),K(236,152),K(238,163),K(252,153),K(256,153),K(270,163),K(272,159),K(282,161),K(283,204)] },
      ], content: [] } },
  ],
  life: {
    settings: { reduce_motion_state: "static", show_regions: true },
    wall: [
      mkContent("particles", "wall_content_1", "Birds over the roofs", "", { every_min_s: 6, every_max_s: 11 }),
      mkContent("guest", "wall_content_2", "Mascot peek", "", { every_min_s: 14, every_max_s: 22 }),
    ],
  },
  test: { error_cm: 0, reduce_motion: false },
};

/* action types (framework code: each type knows its controls), named action sets (Global Scene), and per-POI content (Specific Marker) */
const ACTIONS = {
  card:     { label: "Open the card", controls: [] },
  model_wall: { label: "3D on the wall", controls: ["rotate", "zoom", "move", "moments"] },
  model_screen: { label: "3D on screen", controls: ["rotate", "zoom", "moments"] },
  pano:     { label: "360 visit", controls: ["look around", "zoom"] },
  map:      { label: "Today on the map", controls: ["open map", "directions"] },
  then_now: { label: "Then & now", controls: ["wipe"] },
  play:     { label: "Video / audio", controls: ["play", "scrub"] },
  ask:      { label: "Ask the guide", controls: [] },
  navigate: { label: "Navigate here", controls: [] },
  favourite:{ label: "Favourite", controls: [] },
  share:    { label: "Photo & share", controls: [] },
  tour:     { label: "Start a tour here", controls: [] },
  quiz:     { label: "Quiz", controls: [] },
};
D.pois[0].actions = { model: { file: "twin_tower_church.glb", controls: { rotate: true, zoom: true, move: false }, moments: [{ name: "Rebuild the church", plays: "Timeline · Reconstruct" }, { name: "1755: the earthquake", plays: "Timeline · Earthquake" }] } };
D.pois[1].actions = { model: { file: "", controls: { rotate: true, zoom: true, move: false }, moments: [] } };
D.pois[2].actions = { model: { file: "", controls: { rotate: true, zoom: true, move: false }, moments: [] } };
D.pois[3].actions = { model: { file: "castle_photogrammetry.fbx", controls: { rotate: true, zoom: true, move: true }, moments: [{ name: "The castle at night", plays: "Timeline · Night" }] } };
D.app = { theme: "premium",
  start: { loading_lines: true },
  onboarding: { on: true, ask_style: true, ask_language: true, ask_interests: true },
  main: { search: "bottom", voice: true, filter: true, ask: "bottom-right", explore: "bottom-left", profile: "top-right" },
  explore: { tours: true, games: true, moments: true, layers: false },
  tap: { default_layout: "tap_layout_2", offscreen: "pin", keep_inside: true, card_yields: true },
  pointing: { sel_look: "chip", others: "top", max: 3, rank: "level_distance", min_level: "any", look: "chip", how_far: "off", while_tapped: false },
};
D.experiences = { moments: [
  { key: "moment_1", name: "1755: the earthquake", plays: "Timeline · Earthquake (whole wall)" },
  { key: "moment_2", name: "Day → night", plays: "Wall Life K1 · night repaint, all POIs" } ],
  tours: [
  { key: "tour_1", name: "Churches of the old city", theme: "Architecture", stops: ["castle_hill", "domed_church", "twin_tower_church"], minutes: 8 },
  { key: "tour_2", name: "Down to the river", theme: "Maritime", stops: ["castle_hill", "arched_gate", "twin_tower_church"], minutes: 9 } ],
  games: [
  { key: "game_1", name: "Put it back", type: "Find & place", pois: 3, rule: "drag each floating piece onto its POI; harder each round" },
  { key: "game_2", name: "Quiz rally", type: "Quiz rally", pois: 3, rule: "find the POIs, 5 questions each, against the clock" } ] };

/* media for the Media fill: the style says how (fit, opacity, feather), the shape says which file */
D.media = [
  { key: "media_1", name: "Sunset over the river (sample video)", type: "video", src: "gen:sunset" },
  { key: "media_2", name: "Azulejo panel (sample image)", type: "image", src: "gen:azulejo" },
  { key: "media_3", name: "The wall in 1755 (sample image)", type: "image", src: "gen:then" },
  { key: "photo_castle_day", name: "São Jorge Castle, today (photo)", type: "image", src: "photo:castle_day" },
  { key: "photo_castle_night", name: "São Jorge Castle, at night (photo)", type: "image", src: "photo:castle_night" },
];
