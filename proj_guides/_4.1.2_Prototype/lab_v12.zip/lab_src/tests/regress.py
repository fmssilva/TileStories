"""Feature inventory of the World Editor Lab: run it on a build, get a JSON report; compare two reports.
usage: python3 regress.py <index.html> <report.json>"""
import asyncio, json, os, sys
OPEN_ALL = """(()=>{const ids=new Set();for(let i=0;i<8;i++){const hs=[...document.querySelectorAll('#edb .fold:not(.open) > .fh:not(.locked)')];if(!hs.length)break;hs.slice(0,60).forEach(h=>h.click())}})()"""
from playwright.async_api import async_playwright

async def main(page_path, out_path):
    R = {"errors": [], "checks": {}, "tabs": {}, "screens": {}}
    def check(name, ok, info=""): R["checks"][name] = {"ok": bool(ok), "info": info}
    async with async_playwright() as p:
        b = await p.chromium.launch(**({"executable_path": "/usr/bin/google-chrome"} if os.path.exists("/usr/bin/google-chrome") else {}), args=["--no-sandbox"])
        pg = await b.new_page(viewport={"width": 1440, "height": 900})
        pg.on("console", lambda m: R["errors"].append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: R["errors"].append("PAGEERR " + str(e)))
        await pg.goto("file://" + page_path); await pg.wait_for_timeout(600)
        js = lambda s: pg.evaluate(s)
        # the whole wall on a landscape tablet, seen straight on
        await pg.evaluate("ui.device='tablet_l'; buildDevice(); ui.cam={cx:.5,cy:.5,z:Math.min(dev.SW/IMA,dev.SH)/dev.base,r:0,yaw:0,pitch:0}; camChanged(false)"); await pg.wait_for_timeout(300)
        async def click_wall(x, y):   # wall px (640 × 441.5) → through the camera → a click
            c = await pg.evaluate(f"wallToClient({x},{y})"); await pg.mouse.click(c["x"], c["y"])
        async def nonblank():
            return await js("(()=>{const c=document.getElementById('cv'),x=c.getContext('2d'),d=x.getImageData(0,0,c.width,c.height).data;let s=0,s2=0,n=0;for(let i=0;i<d.length;i+=4000){s+=d[i];s2+=d[i]*d[i];n++}const m=s/n;return s2/n-m*m>50})()")
        async def headers():
            return await js("[...document.querySelectorAll('#edb .fh .ft, #edb .grp, #edb .poih .ft, #edb .dcard h4')].map(e=>e.textContent.trim())")
        async def editor_tab(tid, name):
            await pg.click(tid); await pg.wait_for_timeout(250)
            R["tabs"][name] = {"headers": await headers(), "rows": await js("document.querySelectorAll('#edb .urow').length")}
        # editor tabs (default: every section collapsed)
        check("every editor section starts collapsed", await js("(()=>{document.querySelector('#tab-global').click();return document.querySelectorAll('#edb .fold.open').length===0})()"))
        for tid, name in [("#tab-app", "App"), ("#tab-global", "Global"), ("#tab-specific", "Specific"), ("#tab-exp", "Experiences"), ("#tab-lab", "Decisions")]:
            await editor_tab(tid, name)
        # screens
        await pg.click("#tab-global")
        for s in ["wall", "style", "precision", "life"]:
            await pg.click(f"#stabs button[data-screen={s}]"); await pg.wait_for_timeout(500)
            R["screens"][s] = {"nonblank": await nonblank(), "hud": await js("document.getElementById('hud').textContent")}
        await pg.click("#stabs button[data-screen=app]"); await pg.wait_for_timeout(300)
        R["screens"]["app"] = {"phone": await js("!!document.querySelector('.ph')"), "device buttons": await js("document.querySelectorAll('#devbtns button').length")}
        # features (camera back to the whole wall: the Style and Precision screens frame their own view)
        await pg.evaluate("ui.cam={cx:.5,cy:.5,z:Math.min(dev.SW/IMA,dev.SH)/dev.base,r:0,yaw:0,pitch:0}"); 
        await pg.click("#stabs button[data-screen=wall]"); await pg.click("#tab-global"); await pg.wait_for_timeout(500)
        await pg.evaluate("cancelAnimationFrame(camAnim); ui.cam={cx:.5,cy:.5,z:Math.min(dev.SW/IMA,dev.SH)/dev.base,r:0,yaw:0,pitch:0}; camChanged(false)")
        await pg.evaluate("ui.open['styles']=true; renderEditor()"); await pg.wait_for_timeout(200)
        check("region styles = 7", await js("document.querySelectorAll('#edb canvas.sw').length") == 7)
        check("precision chips in cm", (await js("document.querySelector('[data-chip]').textContent")).startswith("hides"))
        await pg.evaluate("ui.open['style_body']=true; renderEditor()"); await pg.evaluate(OPEN_ALL)
        check("fill modes = 5", await js("(()=>{ui.open['st_fill']=true;renderEditor();return [...document.querySelectorAll('#edb select')].find(s=>[...s.options].some(o=>o.value==='media'))?.options.length})()") == 5)
        check("focus presets include appear", await js("[...document.querySelectorAll('#edb select option')].some(o=>o.value==='appear') || (ui.open['st_motion']=true,renderEditor(),[...document.querySelectorAll('#edb select option')].some(o=>o.value==='appear'))"))
        await pg.evaluate("ui.open['levels']=true; renderEditor()")
        check("levels layers P R T M", await js("document.querySelectorAll('#edb input[type=checkbox][title], #edb label[title] input').length") >= 12)
        check("categories editable", await js("(()=>{ui.open['cats']=true;renderEditor();return document.querySelectorAll('#edb input[type=color]').length>=3})()"))
        # specific: draw a polygon, undo
        await pg.click("#tab-specific"); await pg.wait_for_timeout(200)
        n0 = await js("D.pois[0].world.shapes.length")
        await pg.click("#tools button[data-tool=polygon]")
        for x, y in [(40, 250), (110, 250), (110, 320)]: await click_wall(x, y)
        await pg.keyboard.press("Enter"); await pg.wait_for_timeout(200)
        check("draw a polygon adds a shape", await js("D.pois[0].world.shapes.length") == n0 + 1)
        await pg.click("#undo"); await pg.wait_for_timeout(200)
        check("undo removes it", await js("D.pois[0].world.shapes.length") == n0)
        await pg.evaluate(OPEN_ALL)
        check("shape media select for the door", await js("(()=>{ui.poi=0;ui.shape=1;ui.open['shape']=true;renderEditor();return [...document.querySelectorAll('#edb select option')].some(o=>o.value==='media_1')})()"))
        check("content for actions: model moments", await js("(()=>{ui.tab='specific';ui.open['poi_0']=true;ui.open['acts_0']=true;renderEditor();return [...document.querySelectorAll('#edb input')].some(i=>i.value==='1755: the earthquake')})()"))
        # play: tap the twin-tower church (quiet style appears), door media, sheet text by tap result
        await pg.click("#play"); await pg.wait_for_timeout(1600)
        await click_wall(536, 300); await pg.wait_for_timeout(700)
        check("tap shows the level's layout on the wall (Radial)", await js("document.querySelectorAll('#tapwall .a-rad').length") >= 4)
        check("focus set on the church", await js("focus") == 0)
        await click_wall(20, 30); await pg.wait_for_timeout(300)
        check("tap wall deselects", await js("focus") is None)
        # wall life
        await pg.click("#stabs button[data-screen=life]"); await pg.wait_for_timeout(1500)
        check("wall life kinds K1..K6 present", sorted(await js("allContent().map(o=>KINDS[o.c.kind].code)")) == ["K1", "K2", "K3", "K4", "K5", "K6"])
        await click_wall(579, 131); await pg.wait_for_timeout(1200)
        check("shutters open on focus", await js("lifeState(allContent().find(o=>o.c.kind==='hinged'), performance.now()/1000).env") > 0.5)
        await pg.click("#play")
        # app
        await pg.evaluate("ui.device='phone_p'; buildDevice(); ui.cam={...CAM0}")
        await pg.click("#tab-app"); await pg.wait_for_timeout(300)
        check("app main: edge arrow", await js("document.querySelectorAll('.ph .edge').length") >= 1)
        await pg.locator(".ph .mk").nth(0).click(); await pg.wait_for_timeout(800)
        check("app tapped: radial buttons for Hub (5 + more)", await js("document.querySelectorAll('.ph .a-rad').length") == 6)
        check("app tapped: chip tag shown", await js("!!document.querySelector('.ph .t-chip')"))
        for k, sel_ in [("tap_layout_1", ".a-cap"), ("tap_layout_3", ".t-imm"), ("tap_layout_4", ".t-pan"), ("tap_layout_5", ".tiles"), ("tap_layout_6", ".s-card .ban")]:
            await pg.evaluate(f"(()=>{{ui.previewLayout='{k}';renderPhone();}})()"); await pg.wait_for_timeout(300)
            check(f"layout {k} renders {sel_}", await js(f"!!document.querySelector('.ph {sel_}')"))
        for a_, sel_ in [("pano", ".pano"), ("then_now", ".wipe"), ("model_wall", ".cube"), ("card", ".tv")]:
            await pg.evaluate(f"tapAction(D.pois[0], '{a_}', renderPhone)"); await pg.wait_for_timeout(150)
            check(f"action view {a_}", await js(f"!!document.querySelector('.ph {sel_}')"))
            await pg.evaluate("tapState.view=null; renderPhone()")
        await pg.evaluate("tapAction(D.pois[0], 'favourite', renderPhone)")
        check("favourite toggles", await js("tapState.favs['twin_tower_church'] === true"))
        await pg.evaluate("ui.previewLayout=null; tapState.view=null; demoLayout('tap_layout_3')"); await pg.wait_for_timeout(250)
        check("demo: a finger taps the POI", await js("!!document.querySelector('.ph .tapfx')"))
        await pg.wait_for_timeout(1500)
        check("demo: then the layout opens", await js("!!document.querySelector('.ph .t-imm')"))
        await pg.evaluate("ui.open['app_tap']=true; ui.open['tap_styles']=true; renderEditor()")
        check("layouts are one foldout each", await js("document.querySelectorAll('#edb .fold[data-step=tapped] > .fh').length") >= await js("D.tap_layouts.length"))
        await pg.evaluate("ui.appStep='explore'; renderPhone()"); await pg.wait_for_timeout(200)
        check("app explore lists tours+games+moments", await js("document.querySelectorAll('.ph .sheet2 .it').length") == 6)
        await pg.evaluate("ui.open['app_look']=true; renderEditor()"); await pg.wait_for_timeout(100)
        await pg.select_option("#edb .fold.open[data-step] select:has(option[value=kids])", "kids"); await pg.wait_for_timeout(200)
        check("theme toggles to kids", await js("D.app.theme") == "kids" and await js("dev.scr.classList.contains('kids')"))
        await pg.evaluate("D.app.theme='premium'; renderEditor()")
        # camera: the photo media, off-screen modes, the safe area
        await pg.evaluate("ui.appStep='tapped'; ui.appPoi=D.pois.findIndex(p=>p.id==='castle_hill'); tapAction(D.pois[ui.appPoi], 'then_now', renderPhone)"); await pg.wait_for_timeout(200)
        check("then & now uses the castle photo", await js("!!document.querySelector('.ph .wipe') && !document.querySelector('.ph .wipe.nophoto')"))
        await pg.evaluate("tapState.view=null; ui.appStep='tapped'; ui.appPoi=0; D.app.tap.offscreen='pin'; ui.cam={cx:0.1,cy:0.5,z:1.1,r:0}; renderPhone()"); await pg.wait_for_timeout(300)
        check("off-screen POI shrinks to a pin", await js("!!document.querySelector('.ph .pin')"))
        check("the pin stays inside the phone", await js("(()=>{const a=document.querySelector('.ph .pin').getBoundingClientRect(),b=document.querySelector('.ph').getBoundingClientRect();return a.left>=b.left&&a.right<=b.right&&a.top>=b.top&&a.bottom<=b.bottom})()"))
        await pg.evaluate("ui.cam={cx:0.84,cy:0.5,z:1.1,r:0}; renderPhone()")
        await pg.evaluate("ui.tab='app'; ui.open['app_point']=true; renderEditor()")
        check("editor has the tap behaviour rows", await js("[...document.querySelectorAll('#edb .urow label')].some(l=>l.textContent.includes('leaves the screen'))"))
        # devices, side views, glued parts, pointing
        for d in ["phone_l", "tablet_p", "tablet_l", "phone_p"]:
            await pg.evaluate(f"ui.device='{d}'; buildDevice(); renderPhone()"); await pg.wait_for_timeout(150)
            r = await js("(()=>{const r=dev.scr.getBoundingClientRect();return r.width/r.height})()"); want = await js(f"DEVICES['{d}'].w/DEVICES['{d}'].h")
            check(f"device {d} has its screen shape", abs(r - want) < 0.01, f"{r:.3f} vs {want:.3f}")
        check("unproject inverts the projection (side view)", await js("(()=>{ui.cam={cx:.5,cy:.45,z:1.3,r:12,yaw:35,pitch:-15}; applyCam(); const c=wallToClient(300,200), u=unproject(c.x,c.y); return Math.hypot(u.x-300,u.y-200)<0.5})()"))
        await pg.evaluate("ui.cam={...CAM0}; ui.appStep='tapped'; ui.appPoi=0; tapState.view=null; ui.previewLayout='tap_layout_4'; ui.tapAnchor=null; camChanged(false)"); await pg.wait_for_timeout(300)
        check("floating panels are glued to the wall", await js("!!document.querySelector('.ph .glue .t-pan') && !document.querySelector('.ph .ui .t-pan')"))
        g0 = await js("(()=>{const r=document.querySelector('.ph .glue .t-pan .tx').getBoundingClientRect();return [r.left,r.top]})()")
        await pg.evaluate("ui.cam.cx += 0.05; camChanged(false)"); await pg.wait_for_timeout(200)
        g1 = await js("(()=>{const r=document.querySelector('.ph .glue .t-pan .tx').getBoundingClientRect();return [r.left,r.top]})()")
        m0 = await js("wallToClient(D.pois[0].pos.x, D.pois[0].pos.y)")
        check("glued parts move with the wall", abs(g1[0] - g0[0]) > 5, f"{g0} → {g1}")
        await pg.evaluate("ui.cam={...CAM0, yaw:45}; camChanged(false)"); await pg.wait_for_timeout(200)
        par = await js("(()=>{const a=wallToClient(D.pois[0].pos.x,D.pois[0].pos.y), q=camProject(D.pois[0].pos.x,D.pois[0].pos.y,ui.cam,10), r=dev.scr.getBoundingClientRect(); return Math.abs(a.x-(r.left+q.x/100*r.width))})()")
        check("from the side, 10 cm off the wall shows parallax", par > 8, f"{par:.1f}px")
        await pg.evaluate("ui.cam={...CAM0}; ui.previewLayout=null; ui.appStep='main'; D.app.pointing.others='top'; D.app.pointing.max=1; renderPhone()"); await pg.wait_for_timeout(200)
        n1 = await js("document.querySelectorAll('.ph .edge').length")
        await pg.evaluate("D.app.pointing.others='all'; renderPhone()"); await pg.wait_for_timeout(200)
        nall = await js("document.querySelectorAll('.ph .edge').length")
        await pg.evaluate("D.app.pointing.others='off'; renderPhone()"); await pg.wait_for_timeout(200)
        n0 = await js("document.querySelectorAll('.ph .edge').length")
        check("pointing: off / best 1 / all", n0 == 0 and n1 == 1 and nall >= 2, f"{n0}/{n1}/{nall}")
        await pg.evaluate("D.app.pointing.others='top'; D.app.pointing.max=3; renderPhone()")
        check("cards use photos (castle samples)", await js("D.pois.every(p=>p.media&&p.media.hero)"))
        jg = await js("jsonGlobal()")
        check("json preview has the on-tap components", all(k in jg for k in ["tag_components", "action_components", "button_look", "default_style"]))
        # v12: defaults, components, overrides, buttons from content, distance to the marker, device buttons, sticky titles
        await pg.evaluate("ui.device='phone_p'; buildDevice(); ui.cam={...CAM0}; ui.appStep='main'; renderPhone()")
        await pg.click("#devbtns button[data-dev=phone]"); await pg.wait_for_timeout(150)
        d1 = await js("ui.device"); await pg.click("#devbtns button[data-dev=tablet]"); await pg.wait_for_timeout(150)
        d2 = await js("ui.device"); await pg.click("#devbtns button[data-dev=tablet]"); await pg.wait_for_timeout(150)
        d3 = await js("ui.device"); await pg.click("#devbtns button[data-dev=phone]"); await pg.wait_for_timeout(150)
        check("device buttons: click again turns it", (d1, d2, d3) == ("phone_l", "tablet_p", "tablet_l"), f"{d1} {d2} {d3}")
        check("no side panel next to the device", await js("!document.querySelector('.dside')"))
        check("a level with no style uses the app default", await js("(()=>{const l=D.levels[2],k=l.tap_layout;l.tap_layout='';const s=tapStyleOf(D.pois.find(p=>levelOf(p)===l)||{level:l.key}).key;l.tap_layout=k;return s===D.app.tap.default_layout})()"))
        check("region style falls back to the app default", await js("(()=>{const p=D.pois[0],S=p.world.shapes[0],a=[S.style,p.world.style_override,levelOf(p).region_style];S.style='';p.world.style_override='';levelOf(p).region_style='';const k=styleKeyFor(p,S);[S.style,p.world.style_override,levelOf(p).region_style]=a;return k===D.region_default})()"))
        check("POI field override: castle gap 6, rest inherited", await js("(()=>{const c=D.pois.find(p=>p.id==='castle_hill'),L=tapLayoutOf(c);return L.gap===6&&L.key===tapStyleOf(c).key})()"))
        check("buttons come from content (no model → no 3D)", await js("(()=>{const g=D.pois.find(p=>p.id==='arched_gate'),t=D.pois[0];return !poiActions(g).includes('model_wall')&&poiActions(t).includes('model_wall')})()"))
        check("a POI can hide a button (castle: no Save)", await js("!poiActions(D.pois.find(p=>p.id==='castle_hill')).includes('favourite')"))
        gap = await js("""(()=>{const meas=g=>{const L=D.tap_layouts[1],o=L.gap;L.gap=g;ui.appStep='tapped';ui.appPoi=0;ui.previewLayout=L.key;ui.cam=camPoseFor(D.pois[0].pos,50,40,1.1);renderPhone();
          const t=document.querySelector('.ph .ui .t-chip').getBoundingClientRect(),c=wallToClient(D.pois[0].pos.x,D.pois[0].pos.y);L.gap=o;return Math.hypot((t.left+t.right)/2-c.x,(t.top+t.bottom)/2-c.y)};return [meas(0),meas(12)]})()""")
        check("distance to the marker moves the tag away", gap[1] > gap[0] + 15, f"{gap[0]:.0f} → {gap[1]:.0f} px")
        check("tag component without picture", await js("(()=>{const T=D.tap_tags[3],m=T.media;T.media='none';ui.previewLayout='tap_layout_3';renderPhone();const e=document.querySelector('.ph .t-imm');const ok=e&&!e.style.backgroundImage.includes('url');T.media=m;return ok})()"))
        await pg.evaluate("ui.previewLayout=null; ui.appStep='main'; ui.cam={...CAM0, cx:0.3}; D.app.pointing.others='all'; D.app.pointing.how_far='m'; renderPhone()"); await pg.wait_for_timeout(200)
        check("pointing: how far in metres", await js("[...document.querySelectorAll('.ph .edge small')].some(s=>/\\d m$/.test(s.textContent))"))
        await pg.evaluate("D.app.pointing.how_far='deg'; renderPhone()")
        check("pointing: how far in degrees", await js("[...document.querySelectorAll('.ph .edge small')].some(s=>/°$/.test(s.textContent))"))
        await pg.evaluate("D.app.pointing.how_far='off'; D.app.pointing.others='top'; ui.cam={...CAM0}; ui.tab='app'; ui.open['app_tap']=true; ui.open['tap_styles']=true; ui.open['tapL_tap_layout_2']=true; renderEditor(); document.querySelector('#edb').scrollTop=500")
        await pg.wait_for_timeout(150)
        # v12.1: component previews, the marker stays put, readable panels, numbered sections
        await pg.evaluate("ui.compPreview={type:'buttons'}; ui.appStep='tapped'; ui.appPoi=0; ui.cam={...CAM0}; renderPhone()"); await pg.wait_for_timeout(150)
        check("base elements preview: every button in the gallery", await js("document.querySelectorAll('.ph .gal .gi').length===D.tap_actions.length"))
        ok = True
        for t, cls in [("tag_comp_1", "t-label"), ("tag_comp_2", "t-chip"), ("tag_comp_3", "t-card"), ("tag_comp_4", "t-imm"), ("tag_comp_5", "t-pan")]:
            ok = ok and await js(f"(()=>{{ui.compPreview={{type:'tag',key:'{t}'}};renderPhone();return !!document.querySelector('.ph .{cls}')}})()")
        check("every tag component has its own preview", ok)
        ok = True
        for t, cls in [("act_comp_1", "a-rad"), ("act_comp_2", "a-cap"), ("act_comp_3", "irow"), ("act_comp_4", "a-dock"), ("act_comp_5", "tiles")]:
            ok = ok and await js(f"(()=>{{ui.compPreview={{type:'act',key:'{t}'}};renderPhone();return !!document.querySelector('.ph .{cls}')}})()")
        check("every action component has its own preview", ok)
        check("icons inside a compact card are full size", await js("(()=>{ui.compPreview={type:'act',key:'act_comp_3'};renderPhone();const s=document.querySelector('.ph .t-card .irow .i svg').getBoundingClientRect();return s.width>8})()"))
        mk = await js("(()=>{ui.compPreview=null;ui.previewLayout='tap_layout_4';ui.tapAnchor=null;ui.cam={...CAM0};renderPhone();ui.cam.yaw=45;camChanged(false);const d=document.querySelector('.ph .ui .f-dot').getBoundingClientRect(),c=wallToClient(D.pois[0].pos.x,D.pois[0].pos.y);return Math.hypot((d.left+d.right)/2-c.x,(d.top+d.bottom)/2-c.y)})()")
        check("distance from the wall never moves the marker", mk < 3, f"{mk:.1f}px")
        check("floating panel has a glass backing", await js("(()=>{const e=document.querySelector('.ph .t-pan .tx');const c=getComputedStyle(e);return c.backdropFilter.includes('blur')&&c.backgroundImage.includes('gradient')})()"))
        await pg.evaluate("ui.previewLayout=null; ui.cam={...CAM0}; renderPhone()")
        check("App sections are numbered 1-7", await js("(()=>{ui.tab='app';renderEditor();const t=[...document.querySelectorAll('#edb > .fold > .fh .ft')].map(e=>e.textContent);return t.length===7&&t.every((x,i)=>x.startsWith((i+1)+' ·'))})()"))
        await pg.evaluate("ui.open['app_tap']=true; ui.open['tap_styles']=true; ui.open['tapL_tap_layout_2']=true; renderEditor(); document.querySelector('#edb').scrollTop=500")
        check("section titles stick to the top", await js("(()=>{const e=document.querySelector('#edb .fold.open > .fh'),b=document.querySelector('#edb').getBoundingClientRect();return getComputedStyle(e).position==='sticky'&&Math.abs(e.getBoundingClientRect().top-b.top)<8})()"))

        await b.close()
    json.dump(R, open(out_path, "w"), indent=1)
    bad = [k for k, v in R["checks"].items() if not v["ok"]]
    print(f"{len(R['checks'])} checks, {len(bad)} failed {bad}; errors {len(R['errors'])}; headers " + ", ".join(f"{k}:{len(v['headers'])}" for k, v in R["tabs"].items()))
asyncio.run(main(sys.argv[1], sys.argv[2]))
